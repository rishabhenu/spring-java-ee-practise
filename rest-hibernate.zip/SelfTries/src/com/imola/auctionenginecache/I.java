package com.imola.auctionenginecache;

public interface I {

	public static enum ConditionType{
		SLOW,
		MEDIUM,
		FAST
	}
}
