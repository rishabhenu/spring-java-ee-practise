package SpringTutorial33;

import java.util.Random;

public class RandomText {
	
	public static String[] texts= {
			"I'll be back",
			"I'll come back soon.........",
			"miss me................",
			"don't think, I died,,,,,,,I'll be back again...",
			"I can never die",
			"please don't destroy me.......",
			"I love you,,, sanna............"
	};
	
	static Random random=new Random();
	static int index=random.nextInt(texts.length);
			
	public String theText() {
		return texts[index];
	}
	
	public int theLength() {
		return texts[index].length();
	}
}
