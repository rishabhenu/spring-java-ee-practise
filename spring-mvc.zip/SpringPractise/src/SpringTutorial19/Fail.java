package SpringTutorial19;

public class Fail implements Result{

	@Override
	public String getMessage() {
		return "You failed";
	}

	@Override
	public String toString() {
		return "Fail [getMessage()=" + getMessage() + "]";
	}
	
}
