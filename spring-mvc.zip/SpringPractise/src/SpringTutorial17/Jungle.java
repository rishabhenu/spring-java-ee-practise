package SpringTutorial17;

import java.util.*;

public class Jungle {
	
	private String type;
	private Map<String,String> foods=new HashMap<String,String>();

	public void setType(String type)
	{
		this.type=type;
	}
	
	public void setFoods(Map<String,String> foods)
	{
		this.foods=foods;
	}
	
	public Map<String,String> getFoods()
	{
		return foods;
	}
	
	@Override
	public String toString()
	{
		StringBuilder sb=new StringBuilder();
		sb.append(type);
		
		for(Map.Entry<String, String> food:foods.entrySet())
		{
			sb.append("\n"+food.getKey()+" : "+food.getValue());
		}
		return sb.toString();
	}
}
