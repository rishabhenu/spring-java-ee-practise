package SpringTutorial17;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String args[])
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("/SpringTutorial17/beans.xml");
		
		Jungle foods=(Jungle)context.getBean("jungle");
		System.out.println(foods);
		
		foods=(Jungle)context.getBean("sea");
		System.out.println(foods);
		
		((ClassPathXmlApplicationContext)context).close();
	}
}
