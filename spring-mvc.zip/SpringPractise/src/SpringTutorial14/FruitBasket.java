package SpringTutorial14;

import java.util.List;

public class FruitBasket {

	private String name;
	private List<String> fruits;
	
	public FruitBasket() {}
	
	public void addFruits(String fruit)
	{
		fruits.add(fruit);
	}
	
	public FruitBasket(String name,List<String>fruits)
	{
		this.name=name;
		this.fruits=fruits;
	}
	@Override
	public String toString() {
		
		StringBuilder sb=new StringBuilder();
		sb.append(name);
		sb.append(" contains");
		
		for(String s:fruits)
		{
			sb.append("\n"+s);
		}
		return sb.toString();
	}
}
