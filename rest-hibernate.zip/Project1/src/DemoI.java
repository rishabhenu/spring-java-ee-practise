
public interface DemoI {
	public long getId();
	public String getName();
	public DemoI getDemoTable();
}
