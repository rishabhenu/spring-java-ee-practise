package spring7.students;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class StudentsDAO {

	private NamedParameterJdbcTemplate jdbc;
	
	public StudentsDAO() {
		System.out.println("successfully loades studentsDAO");
	}
	
	@Resource(name="dataSource")
	public void setDataSource(DataSource datasource) {
		this.jdbc=new NamedParameterJdbcTemplate(datasource);
	}

	public List<Students> getStudents() {
		
		return jdbc.query("select * from STUDENTS", new RowMapper<Students>() {
			@Override
			public Students mapRow(ResultSet rs,int rowNo) throws SQLException {
				Students students = new Students();
				students.setId(rs.getInt("sid"));
				students.setName(rs.getString("sname"));
				students.setAddress(rs.getString("saddress"));
				return students;
			}
		});
	}
}
