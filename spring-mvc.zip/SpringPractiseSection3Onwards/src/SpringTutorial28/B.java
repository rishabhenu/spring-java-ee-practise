package SpringTutorial28;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class B implements I	{

	@Override
	public String toString() {
		return "Hi! This is class B";
	}
}
