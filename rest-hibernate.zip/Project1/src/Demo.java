
public class Demo {
	private long id;
	private String name;
	@Override
	public String toString() {
		return "Demo [id=" + id + ", name=" + name + "]";
	}
	public Demo() {}

	public void setId(long id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public class InnerDemo implements DemoI{
		@Override
		public long getId() {
			return id;
		}
		@Override
		public String getName() {
			return name;
		}
		@Override
		public DemoI getDemoTable() {
			return null;
		}	
	}
}
