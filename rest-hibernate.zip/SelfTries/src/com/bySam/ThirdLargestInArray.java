package com.bySam;

public class ThirdLargestInArray {

	public static void main(String...strings) {
		ThirdLargestInArray obj=new ThirdLargestInArray();
		int arr[]= {2,3,1,6,10,7,13,11,9};
		int a=arr[0],b=arr[1],c=arr[2];
		int f=obj.largestOfThree(a, b, c, 1);
		int s=obj.largestOfThree(a, b, c, 2);
		int t=obj.largestOfThree(a, b, c, 3);
		
		for(int i=3;i<arr.length;i++) {
			if(arr[i]>f) {
				t=s;s=f;f=arr[i];System.out.println("for i = "+i+" [f,s,t] = ["+f+" "+s+" "+t+"]");
			}else if(arr[i]>s) {
				t=s;s=arr[i];System.out.println("for i = "+i+" [f,s,t] = ["+f+" "+s+" "+t+"]");
			}else if(arr[i]>t) {
				t=arr[i];System.out.println("for i = "+i+" [f,s,t] = ["+f+" "+s+" "+t+"]");
			}
		}
		System.out.println("finally t = "+t);
	}
	
	public int largestOfThree(int a,int b,int c,int rank) {
		int f=Math.max(a, Math.max(b, c));
		int s=Math.max(a, Math.min(b, c));
		int t=Math.min(a, Math.min(b, c));
		switch(rank) {
		case 1:return f;
		case 2:return s;
		case 3:return t;
		}
		return -1;
	}
}
