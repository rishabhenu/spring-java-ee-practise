package spring8.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import spring8.spring8.Spring8;

@Controller
public class MainController {

	@RequestMapping("/")
	public String getHome(Spring8 spring,Model model)
	{
		model.addAttribute("spring8",spring);
		return "home";
	}
}
