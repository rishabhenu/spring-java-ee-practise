package practise;

public class Address {

	int houseno;
	String place;
	
	@Override
	public String toString() {
		return "Address [houseno=" + houseno + ", place=" + place + "]";
	}

	public void setHouseno(int houseno) {
		this.houseno=houseno;
	}
	
	public void setPlace(String place)
	{
		this.place=place;
	}

}
