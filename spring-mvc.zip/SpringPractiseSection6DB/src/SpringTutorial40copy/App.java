package SpringTutorial40copy;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	
	public static void main(String args[]) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringTutorial40copy/beans.xml");
		
		EmpDAO empdao = (EmpDAO)context.getBean("empdao");
		
		List<Emp> emps=empdao.getEmp();
		
		for(Emp emp:emps) {
			System.out.println(emp);
		}
	}

}
