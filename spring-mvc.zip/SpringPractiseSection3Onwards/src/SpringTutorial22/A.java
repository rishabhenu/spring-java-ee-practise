package SpringTutorial22;

public class A implements I{
	
	@Override
	public String toString() {
		return "Hi! This is class A";
	}

	@Override
	public void getI() {
		System.out.println("I implemented in class A");
	}

}
