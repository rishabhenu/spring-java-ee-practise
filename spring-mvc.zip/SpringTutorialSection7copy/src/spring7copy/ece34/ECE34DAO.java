package spring7copy.ece34;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class ECE34DAO {

	public ECE34DAO(){
		System.out.println("loaded ece34dao");
	}
	private NamedParameterJdbcTemplate jdbc;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbc=new NamedParameterJdbcTemplate(dataSource);
	}
	
	/*fetch all records of table*/
	public List<ECE34> getCompleteTable(){
		return jdbc.query("select * from ece34 order by rollno desc", new RowMapper<ECE34>() {

			@Override
			public ECE34 mapRow(ResultSet rs, int rowNum) throws SQLException {
				ECE34 ece=new ECE34();
				ece.setRollno(rs.getInt("rollno"));
				ece.setName(rs.getString("name"));
				ece.setAddress(rs.getString("address"));
				return ece;
			}			
		});
	}
	
//	inserting new record in table
	public int insertECE34(ECE34 ece34) throws SQLException{
		try {
			int i=ece34.getRollno();
			if(ece34.getName().length()>20)ece34.setName(ece34.getName().substring(0, 20));
			if(ece34.getAddress().length()>20)ece34.setAddress(ece34.getAddress().substring(0, 20));
			if(ece34.getRollno()>Integer.MAX_VALUE) {throw new Exception();}
			BeanPropertySqlParameterSource param=new BeanPropertySqlParameterSource(ece34);
			return jdbc.update("insert into ece34(rollno,name,address) values(:rollno,:name,:address)", param);
		}catch(Exception e) {
			System.out.println("data exceed max value");
		}
		return 0;
	}
	
//	update existing record in a table
	public int updateECE34(ECE34 ece34) {
		BeanPropertySqlParameterSource param=new BeanPropertySqlParameterSource(ece34);
		String query="update ece34 set name=:name,address=:address where rollno=:rollno";
		return jdbc.update(query, param);
	}
	
//	deleting null values from table
	public int deleteNull(ECE34 ece34) {
		BeanPropertySqlParameterSource param=new BeanPropertySqlParameterSource(ece34);
		String query="delete from ece34 where name is null or address is null";
		return jdbc.update(query, param);
	}
}
