package SpringTutorial48;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String args[]) {
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringTutorial48/beans48.xml");
		
		ECE34DAO ece34 = (ECE34DAO)context.getBean("ece34dao");
		
		ECE34 values=new ECE34();
		List<ECE34> ece = new LinkedList<ECE34>();		
		
//		ece.add(values.setValues(11302079, "Shivalik", "Fazilka"));
		ece.add(values.setValues("11302091", "Deepak", "Sangrur"));
		
		System.out.println(ece.size());
		
		try{
			ece34.createECE34(ece);
		}catch(Exception sqlex) {System.out.println(sqlex.getMessage());}
		ece=null;
		
		List<ECE34> table=ece34.getECE34();
		
		for(ECE34 ec:table) {
			System.out.println(ec);
		}
	}

}
