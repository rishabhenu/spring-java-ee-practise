package SpringTutorial48;

public class ECE34 {
	
	private String rollno;
	private String name,address;
	public ECE34 setValues(String rollno,String name,String address) {
		ECE34 ece=new ECE34();
		ece.setRollno(rollno);ece.setName(name);ece.setAddress(address);
		return ece;
	}
	@Override
	public String toString() {
		return "ECE34 [rollno=" + rollno + ", name=" + name + ", address=" + address + "]";
	}
	public String getRollno() {
		return rollno;
	}
	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

}
