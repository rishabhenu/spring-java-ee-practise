package com.project1.practise.listiterable;

public class IteratorExampleRunner {
	
	public static void main(String args[]) {
		
		IteratorExample<String> myIterator=new IteratorExample<>();
		
		myIterator.add("Rishu");
		myIterator.add("Neha");
		myIterator.add("Anoop");
		myIterator.add("Nisafi Devi");
		
		for(String str:myIterator) {
			System.out.println(str);
		}
		
	}
	
}
