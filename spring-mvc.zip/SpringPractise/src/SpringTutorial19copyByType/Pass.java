package SpringTutorial19copyByType;

public class Pass implements Result {

	@Override
	public String getMessage() {
		return "Congrats! You passed.";
	}

	@Override
	public String toString() {
		return "Pass [getMessage()=" + getMessage() + "]";
	}	
}
