import java.util.Date;
import java.util.Locale;

public class Dummy {

	public static void main(String...strings) {
		Date date=new Date();
		System.out.println(date);
		
	}
}
