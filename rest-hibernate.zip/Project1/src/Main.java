
public class Main {

	public static void main(String...strings) {
		Demo demo=new Demo();
		demo.setId(10);
		demo.setName("Rishabh");
	}
}
