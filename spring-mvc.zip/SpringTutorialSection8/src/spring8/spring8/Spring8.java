package spring8.spring8;

import javax.validation.constraints.Size;

import spring8.validation.ValidateId;

public class Spring8 {

//	@Size(min=4,max=4)
	@ValidateId(message="Should be four digit positive no")
	private int id;

	@Size(min = 3, max = 20, message = "Name should be b/w 3 to 20 characters")
	private String name;

	@Size(min = 10, max = 255, message = "Please enter some text b/w 10 to 255 characters")
	private String text;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id=id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return "Spring8 [id=" + id + ", name=" + name + ", text=" + text + "]";
	}
}
