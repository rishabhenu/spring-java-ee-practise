package com.controller;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.spring.Spring8;
import com.spring.SpringDAO;

@Controller
public class Main {
	
	Log log=LogFactory.getLog(Main.class);
	
	SpringDAO spring;
	
	public void setSpring(SpringDAO spring) {
		log.info("setting up springdao object");
		this.spring=spring;
	}
	
	@RequestMapping("/")
	public ModelAndView getHome(){
		ModelAndView mv=new ModelAndView("home");
		System.out.println(spring.getSpring8());
		return mv;
	}
	
	@RequestMapping("/spring")
	public ModelAndView getSpring() {
		ModelAndView mv=new ModelAndView("spring");
		try {
			List<Spring8> list=spring.getSpringTable();
			System.out.println(list);
		}catch(Exception e) {
			System.out.println("exception "+e.getMessage());
		}
		return mv;
	}
}
