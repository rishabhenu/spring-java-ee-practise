import java.util.*;

public class MapEntryMethod {

	public static void main(String args[])
	{
		Map<String,Integer> map=new LinkedHashMap<String,Integer>();
		
		map.put("Rishu", 1);
		map.put("Neha", 3);
		map.put("Anoop", 2);
		map.put("Ravi", 1);
		
		Set<Map.Entry<String, Integer>>	entries=new TreeSet<>();
		
		entries=map.entrySet();
		
		for(Map.Entry<String, Integer> entry:entries)
		{
			String key=entry.getKey();
			int value=entry.getValue();
			
			System.out.println("Key "+key+" : Value "+value);
		}
	}
}
