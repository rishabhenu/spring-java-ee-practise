package com.email;

public interface ConstantTableI {

	public static enum NotificationType{
		LOGIN_ALERT,
		ACCOUNT_CREATED
	}
	
	public static enum ErrorType{
		
	}
}
