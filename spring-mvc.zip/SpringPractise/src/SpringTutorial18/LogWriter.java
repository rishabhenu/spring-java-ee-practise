package SpringTutorial18;

public class LogWriter {

	@Override
	public String toString() {
		return "Hello! This is LogWriter";
	}

}
