package SpringTutorial28;

import org.springframework.beans.factory.annotation.Qualifier;

@Qualifier("abc")
public class A implements I{
	
	@Override
	public String toString() {
		return "Hi! This is class A";
	}

}
