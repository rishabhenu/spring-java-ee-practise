package com.resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.resteasy.links.LinkResource;

import com.random.RandomCal;

@Path("/dummy")
public class Dummy {

	private Log log=LogFactory.getLog(Dummy.class);
	private RandomCal randomCal;
	
	@GET
	@Produces({MediaType.TEXT_PLAIN,MediaType.APPLICATION_XML})
	public String getResponse() {
		log.info("get method called under class having path(/dummy)");
		log.info(randomCal);
		return "hello";
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getArray")
	public String[] getArray(){
		log.info("getArray method called");
		return new String[]{"rishabh","pavan","darshan"};
	}
	
	@GET
	@LinkResource(RandomCal.class)
	@Path("/randomcal")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public RandomCal getRandomCal() {
		return randomCal;
	}

	public void setRandomCal(RandomCal randomCal) {
		this.randomCal = randomCal;
	}
}
