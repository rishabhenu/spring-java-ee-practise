package com.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {
	
	public LoginController() {
		// TODO Auto-generated constructor stub
	}
	@RequestMapping(name="/myLogin")
	public String login(Model model,HttpServletRequest request) {
		if(request.getParameter("error")!=null) {model.addAttribute("loginerror","Your login attempt was not successful, try again.");}
		return "myLogin";
	}
	@RequestMapping(value="/createuser")
	public String creaeUser(Model model) {
		return "createuser";
	}
	@RequestMapping(value="admin/createadmin")
	public String creaeAdmin(Model model) {
		return "admin/createadmin";
	}
}
