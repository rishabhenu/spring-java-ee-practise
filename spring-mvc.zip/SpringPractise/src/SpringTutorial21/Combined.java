package SpringTutorial21;

public class Combined {
	
	Class001 class001;
	Class002 class002;
	
	
	@Override
	public String toString() {
		return "Combined [class001=" + class001 + ", class002=" + class002 + "]";
	}


	public Combined(Class001 class001, Class002 class002) {
		this.class001 = class001;
		this.class002 = class002;
	}
	
	

}
