package jdbc.connectingOracle.UsingDataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

public class StudentsDAO {

	private JdbcTemplate jdbc;
	public BasicDataSource setDataSource() {
		BasicDataSource datasource = new BasicDataSource();
		datasource.setUsername("SYSTEM");
		datasource.setPassword("password");
		datasource.setUrl("jdbc:oracle:thin:@localhost:1521:orcl");
		datasource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		return datasource;
	}

	public List<Students> getStudents() {

		jdbc=new JdbcTemplate(setDataSource());
		return jdbc.query("select * from Students", new RowMapper<Students>() {
			@Override
			public Students mapRow(ResultSet rs, int rowNo) throws SQLException {
				Students students = new Students();
				students.setS_id(rs.getInt("id"));
				students.setS_name(rs.getString("name"));
				students.setA_address(rs.getString("address"));
				return students;
			}
		});
	}
}
