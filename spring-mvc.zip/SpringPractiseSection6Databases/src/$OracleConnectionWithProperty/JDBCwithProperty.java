package $OracleConnectionWithProperty;

public final class JDBCwithProperty {

	private String user;
	private String password;	
	
	public JDBCwithProperty(String user, String password) {
		this.user = user;
		this.password = password;
	}

	public String getUser() {
		return user;
	}
	public String getPassword() {
		return password;
	}

	public void speak() {
		System.out.println("speaking..................");
	}
	
}
