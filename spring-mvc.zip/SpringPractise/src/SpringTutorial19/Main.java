package SpringTutorial19;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String args[])
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("SpringTutorial19/beans.xml");
		
		HaveResult haveresult=(HaveResult)context.getBean("haveresult");
		
		System.out.println(haveresult);
		
		((ClassPathXmlApplicationContext)context).close();
	}

}
