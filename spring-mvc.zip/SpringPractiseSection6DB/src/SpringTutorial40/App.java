package SpringTutorial40;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String args[]) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringTutorial40/beans.xml");
		
		StudentsDAO studentsdao=(StudentsDAO)context.getBean("studentsdao");
		
		List<Students> students = studentsdao.getStudents();

		((ClassPathXmlApplicationContext)context).close();
		
		for(Students student:students) {
			System.out.println(student);
		}
	}
}
