package SpringTutorial32;

import org.springframework.stereotype.Component;

@Component
public class Junglee {

	public String toString() {
		return "junglee janwar...........";
	}
}
