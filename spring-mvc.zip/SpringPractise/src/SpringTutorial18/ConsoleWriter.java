package SpringTutorial18;

public class ConsoleWriter {

	@Override
	public String toString() {
		return "Hi! This is consoleWriter.";
	}
	
	
}
