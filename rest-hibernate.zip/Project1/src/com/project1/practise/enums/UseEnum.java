package com.project1.practise.enums;

public class UseEnum {
	
	public static void main(String...strings) {
//		if(high != null)
		Level level=Level.low;
		
		System.out.print(level.level+" ");
		System.out.println(level.toString());
		
		switch(level.level) {
		case 10:
			System.out.println("high");
			break;
		case 7:
			System.out.println("medium");
			break;
		case 5:
			System.out.println("low");
			break;
		}
	}

}
