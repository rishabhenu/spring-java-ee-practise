package com.amiti.interviews;

public class Stack {

	static private Object[] arr=null;
	private int top;
	
	public Stack() {
		arr=new Object[10];
		top=0;
	};
	
	/*pushes an item onto the top*/
	public Stack push(Object o) {
		arr[top]=o;
		top++;
		if(top==arr.length) {
			Object temp[]=arr.clone();
			arr=new Object[top*2];
			for(int i=0;i<top;i++) {
				arr[i]=temp[i];
			}
		}
		return this;
	}
	
	/*removes the object at the top*/
	public Object pop() {
		top--;
		try {
			Object temp=arr[top];
			arr[top]=null;
			return temp;
		}catch(ArrayIndexOutOfBoundsException e) {
			return null;
		}
	}
	
	/*return the 1-based ************************/
	public int search(Object o) {
		for(int i=top;i>=0;i--) {
			if(arr[i]==o) {
				return top-i;
			}
		}
		return -1;
	}
}
