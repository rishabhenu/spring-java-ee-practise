package SpringTutorial45;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String...strings) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringTutorial45/beans45.xml");
		
		DeptDAO deptdao=(DeptDAO)context.getBean("deptdao");
		
//		deptdao.deleteDept(50);
//		
//		System.out.println("complete");
		
		List<Dept> depts = deptdao.getDept();
		
		((ClassPathXmlApplicationContext)context).close();
		
		for(Dept dept:depts) {
			System.out.println(dept);
		}
	}
	
}
