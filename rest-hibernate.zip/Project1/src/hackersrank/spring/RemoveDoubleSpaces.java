package hackersrank.spring;

public class RemoveDoubleSpaces {
	
	public static void main(String args[]) {
		System.out.println("starting........");
		RemoveDoubleSpaces obj=new RemoveDoubleSpaces();
		String input="neha  sha              rma and rish    abh";
		System.out.println(input.contains("  "));
		input=obj.removeSpaces(input);
		System.out.println(input);
	}
	
	public String removeSpaces(String s) {
		if(s.contains("  ")) {
			return removeSpaces(s.replace("  ", " "));
		}
		else {
			return s;
		}
	}
	
}
