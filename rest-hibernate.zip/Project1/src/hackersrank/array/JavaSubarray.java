package hackersrank.array;

import java.util.Scanner;

public class JavaSubarray {
	static Scanner scan=new Scanner(System.in);
	public static void main(String...strings)
	{		
		System.out.println("enter length");
		
		int length=scan.nextInt();
		scan=null;
		
		scan=new Scanner(System.in);
		
		System.out.println("enter elements seperated by space");
		
		String str=scan.nextLine();
		
		scan.close();
		System.out.println(length);
//		System.out.println(str);
		
		int inputarr[]=new int[length];
		for(int i=0;i<length;i++)
		{
			inputarr[i]=Integer.parseInt(str.split(" ")[i]);
		}
		int count=new JavaSubarray().getCount(inputarr);
		System.out.println(count);
	}
	
	public int getCount(int arr[]) {
		int count=0;
		for(int i=1;i<=arr.length;i++)
		{
			for(int j=0;j<=arr.length-i;j++)
			{
				int sum=0;
				for(int k=j;k<j+i;k++)
				{
					System.out.print(arr[k]+" ");
					sum+=arr[k];
				}
				if(sum<0) {count+=1;}
				System.out.println(" sum= "+sum+"    count = "+count);
			}
		}
		return count;
	}
}
