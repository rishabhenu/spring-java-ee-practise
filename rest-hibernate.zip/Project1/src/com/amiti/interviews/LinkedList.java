package com.amiti.interviews;

import javax.xml.soap.Node;

public class LinkedList {

	Node node;
	
	public static void main(String...strings) {
		System.out.println();
	}
}
