package SpringTutorial53;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PrintHello {

	@RequestMapping("/")
	public String sayHello(Model model) {
		model.addAttribute("name", "Rishabh Sharma");
		model.addAttribute("job", "<b>Software Developer</b>");
		return "home";
	}
}
