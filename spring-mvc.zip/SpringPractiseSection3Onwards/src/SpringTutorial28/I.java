package SpringTutorial28;

public interface I {
}
