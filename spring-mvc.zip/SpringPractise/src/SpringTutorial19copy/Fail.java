package SpringTutorial19copy;

public interface Fail {
	
	public String fail();
}
