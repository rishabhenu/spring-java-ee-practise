package spring9.tutorial77;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String...strings) {
		
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("spring9/tutorial77/beans77.xml");
		
		Camera camera=(Camera)context.getBean("camera");
		
		camera.photo();
		
		context.close();
		
	}
}
