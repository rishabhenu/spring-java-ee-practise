package SpringTutorial19copy;

public class HaveResult {
	
	Pass pass;
	Fail fail;
	
	public void setPass(Pass pass) {
		this.pass = pass;
	}
	public void setFail(Fail fail) {
		this.fail = fail;
	}
	@Override
	public String toString() {
		return "HaveResult [pass=" + pass + ", fail=" + fail + "]";
	}

}
