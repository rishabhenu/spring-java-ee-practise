package com.telusko.rest.demorest;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.telusko.rest.resources.Alien;
import com.telusko.rest.resources.AlienRepository;

@Path("aliens")
public class AlienResource {

	private AlienRepository repo = new AlienRepository();

	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public List<Alien> getAlien() {
		return repo.getAliens();
	}

	@GET
	@Path("alien/{id}")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Alien getAlien(@PathParam("id") int id) {
		return repo.getAliens(id);
	}

	 @POST
	 @Path("alien")
	 public List<Alien> createAlien(Alien a) {
	 repo.createAliens(a);
	 return repo.getAliens();
	 }
}
