package hackersrank.array;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CompareTheTriplet {

	// Complete the compareTriplets function below.
    static List<Integer> compareTriplets(List<Integer> a, List<Integer> b) {
        List<Integer> result=new ArrayList<Integer>();
        result.add(0,0);
        result.add(1,0);
        boolean a0,a1,a2,b0,b1,b2;
        a0=(a.get(0)>=1||a.get(0)<=100);
        a1=(a.get(1)>=1||a.get(1)<=100);
        a2=(a.get(2)>=1||a.get(2)<=100);
        b0=(b.get(0)>=1||b.get(0)<=100);
        b1=(b.get(1)>=1||b.get(1)<=100);
        b2=(b.get(2)>=1||b.get(2)<=100);
        if(a0&&a1&&a2&&b0&&b1&&b2) {
        	for(int i=0;i<=2;i++) {
        		if(a.get(i)<b.get(i)) {
        			result.add(1, result.get(1)+1);
        		}
        		else if(a.get(i)>b.get(i)) {
        			result.add(0, result.get(0)+1);
        		}
        	}
        	return result;
        }
        return null;
    }

    public static void main(String[] args) throws IOException {
    	CompareTheTriplet obj=new CompareTheTriplet();
    	Integer[] a=new Integer[] {0,0};
    	a[0]++;
    	a[1]++;
    	
    	List<Integer> list=Arrays.asList();
    	System.out.println(list);
    	for(int i:a) {
    		System.out.println(i);
    	}
    }    
}