package SpringTutorial45copy;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String args[]) {
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringTutorial45copy/beans45copy.xml");
		
		AmitiDAO amitidao=(AmitiDAO)context.getBean("amitidao");
		
//		amitidao.insertAmiti(9, "GEEKS CLUB", "SHIVAM");
//		amitidao.updateAmiti(9, "Shubhham Jha");

		
		List<Amiti> amiti=amitidao.getAmiti();

		for(Amiti am:amiti) {
			System.out.println(am);
		}
		
//		amitidao.deleteAmiti("delete from amiti where empid=9");
	}

}
