package com.ece;

public class ECE34 {

	private int rollno;
	private String name;
	private String address;
	
	@Override
	public String toString() {
		return "ECE34 [rollno=" + rollno + ", name=" + name + ", address=" + address + "]";
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
