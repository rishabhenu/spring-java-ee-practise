
public class democlass {

}
