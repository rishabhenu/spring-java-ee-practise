package SpringTutorial18;

public class FileWriter {
	
	@Override
	public String toString()
	{
		return "Hi! This is filewriter";
	}

}
