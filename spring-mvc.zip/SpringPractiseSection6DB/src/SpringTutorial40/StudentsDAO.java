package SpringTutorial40;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class StudentsDAO {

	private JdbcTemplate jdbc;
	
	@Autowired
	public void setDataSource(DataSource datasource) {
		this.jdbc=new JdbcTemplate(datasource);
	}

	public List<Students> getStudents() {
		
		return jdbc.query("select * from STUDENTS", new RowMapper<Students>() {
			@Override
			public Students mapRow(ResultSet rs,int rowNo) throws SQLException {
				Students students = new Students();
				students.setId(rs.getInt("sid"));
				students.setName(rs.getString("sname"));
				students.setAddress(rs.getString("saddress"));
				return students;
			}
		});
	}
}
