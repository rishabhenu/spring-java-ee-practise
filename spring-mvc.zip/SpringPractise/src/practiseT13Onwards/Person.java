package practiseT13Onwards;

public class Person {
	
	private int id;
	private String name;
	
	private Address address;
	
	public static Person getInstance(int id,String name)
	{
		System.out.println("object created using factory method");
		return new Person(id,name);
	}
	
	public void setAddress(Address a) {
		this.address=a;
	}
	
	public Person(int id, String name) 
	{
		this.id = id;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", address=" + address + "]";
	}

	public void speak()
	{
		System.out.println("speak method of person class");
	}

}
