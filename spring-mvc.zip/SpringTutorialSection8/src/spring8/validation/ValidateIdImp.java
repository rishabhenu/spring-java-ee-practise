package spring8.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidateIdImp implements ConstraintValidator<ValidateId, Integer> {

	@Override
	public boolean isValid(Integer value, ConstraintValidatorContext context) {
		try {
			int i = value;
			if (i < 1000 || i > 9999) {
				return false;
			}
		} catch (java.lang.NumberFormatException e) {
			return false;
		}
		return true;
	}

}
