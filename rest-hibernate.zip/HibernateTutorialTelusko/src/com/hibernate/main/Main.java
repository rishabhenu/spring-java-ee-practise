package com.hibernate.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.database.Aliens;

public class Main {

	public static void main(String... strings) {

		Aliens alien = new Aliens();

		Configuration con = new Configuration().configure("com/configurations/database-config.xml")
				.addAnnotatedClass(Aliens.class);

		SessionFactory sf = con.buildSessionFactory();

		Session session = sf.openSession();

		Transaction tx = session.beginTransaction();
		
//		session.save(alien);
		
		alien = (Aliens) session.get(Aliens.class, 2);

		System.out.println(alien);
		tx.commit();

//		System.out.println(alien);
	}

}
