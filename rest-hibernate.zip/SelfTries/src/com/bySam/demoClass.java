package com.bySam;

public class demoClass {

	public static void main(String...a) {
		
	}
	
}
