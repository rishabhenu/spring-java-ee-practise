package SpringTutorial34;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RandomSpeech {
	
	static private Random random=new Random();
	
	private static String[] texts= {
			"I'll be back soon",
			"hey Dr. pls don't destroy me......",
			"sanna! I love you very much....",
			"my name is robo,,,,,,,,,,"
	};
	
	static private int index=random.nextInt(texts.length);
	
	@Autowired
	public int getLength() {
		return texts[index].length();
	}
	
	@Autowired
	public String getText() {
		return texts[index];
	}

}
