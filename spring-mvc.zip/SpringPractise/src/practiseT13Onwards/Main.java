package practiseT13Onwards;

import org.springframework.context.*;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Main {
	
	public static void main(String[] args)
	{
		ApplicationContext context = new FileSystemXmlApplicationContext("/src/practiseT13Onwards/beansFile/beans.xml");
		
		Person person=(Person)context.getBean("person");
		person.speak();
		
		System.out.println("person "+person);
		
		Address address = (Address)context.getBean("address");
		System.out.println("Address "+address);
		
		Address address1=(Address)context.getBean("address1");
		System.out.println("Address1 "+address1);
		
		((FileSystemXmlApplicationContext)context).close();
	}

}
