package com.amiti.interviews;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class OwnLinkedList {
	
	Log log = LogFactory.getLog(OwnLinkedList.class);
	private Object arr[]=null;
	private int index;
	
	public OwnLinkedList() {
		arr=new Object[10];
		index=0;
	}
	public void add(Object o) {
		log.info("Object "+o+" added");
		arr[index]=o;
		index++;
		if(index==arr.length) {
			Object obj[]=arr.clone();
			log.info("size of list is increased");
			arr=new Object[index*2];
			for(int i=0;i<index;i++) {
				arr[i]=obj[i];
			}
		}
	}
	public Object get(int index) {
		try {
			if(arr[index]==null) {
				log.error("trying to get object at some index i.e. not availabe yet");
				throw new Exception();
			}
			log.info("object at index "+index+" is returned");
			return arr[index];
		}catch(Exception e) {
			log.error("trying to get object at some index i.e. not availabe yet");
			System.out.println("Info : ArrayIndexOutOfBoundsException, size= "+this.index+" index = "+index);
		}
		return null;
	}
	public boolean remove(Object o) {
		for(int i=0;i<index;i++) {
			if(arr[i]==o) {
				for(int j=i;j<index-1;j++) {
					arr[j]=arr[j+1];
				}
				arr[index-1]=null;
				index--;
				return true;
			}
		}
		return false;
	}
	public boolean remove(int index) {
		try {
			for(int i=index;i<this.index-1;i++) {
				arr[i]=arr[i+1];
			}
			arr[this.index-1]=null;
			this.index--;
			return true;
		}catch(ArrayIndexOutOfBoundsException e) {
			return false;
		}
	}
	public int size() {
		return index;
	}
}
