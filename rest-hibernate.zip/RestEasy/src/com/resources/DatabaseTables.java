package com.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.database.amiti.Amiti;
import com.database.amiti.AmitiServicesDAO;

@Path("/tables")
public class DatabaseTables {
	static private Log log = LogFactory.getLog(DatabaseTables.class);

	private AmitiServicesDAO amitiServicesDao;

	public void setAmitiServicesDao(AmitiServicesDAO amitiServices) {
		this.amitiServicesDao = amitiServices;
	}
	
	@POST
	@Path("/amiti")
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Amiti createAmitiTable(Amiti amiti) {
		boolean b=amitiServicesDao.insertAmitiTable(amiti);
		if(b) {return getAmitiTable(amiti.getEmpid());}
		return null;
	}
	
	@GET
	@Path("/amiti/{empid}")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Amiti getAmitiTable(@PathParam("empid")int empid) {
		return amitiServicesDao.getAmitiTableById(empid);
	}
	@GET
	@Path("/amiti")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public List<Amiti> getAmitiTable() {
		return amitiServicesDao.getAmitiTable();
	}
	
	@GET
	@Path("test1/resolve/{vin}")
	@Produces({MediaType.APPLICATION_JSON})
	public String getStatus(@PathParam("vin")String vin) {
		log.info("entering method to update");
		return (amitiServicesDao.updateTimer(vin))?"success":"failed";
	}
}
