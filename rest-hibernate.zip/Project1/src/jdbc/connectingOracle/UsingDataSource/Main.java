package jdbc.connectingOracle.UsingDataSource;

import java.util.List;

public class Main {
	
	public static void main(String args[]) {

		StudentsDAO studentsdao = new StudentsDAO();
		
		List<Students> students=studentsdao.getStudents();
		
		for(Students student:students) {
			System.out.println(student);
		}
		
	}

}
