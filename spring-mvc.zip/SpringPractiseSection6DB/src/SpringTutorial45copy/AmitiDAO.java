package SpringTutorial45copy;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

@Component
public class AmitiDAO {

	private NamedParameterJdbcTemplate jdbc;
	
	@Autowired
	public void setDataSource(DataSource datasource) {
		this.jdbc=new NamedParameterJdbcTemplate(datasource);
	}
	
	public int deleteAmiti(String query) {
		MapSqlParameterSource param = new MapSqlParameterSource();
		return jdbc.update(query, param);
	}
	
	public int insertAmiti(Amiti amiti) {
		BeanPropertySqlParameterSource param=new BeanPropertySqlParameterSource(amiti);
		return jdbc.update("insert into amiti values(:empid,:ename,:egroup)", param);
	}
	
	public int updateAmiti(int empid,String ename) {
		Amiti amiti=new Amiti(empid,ename);
		BeanPropertySqlParameterSource param=new BeanPropertySqlParameterSource(amiti);
		return jdbc.update("update amiti set ename=:ename where empid=:empid", param);
	}
	
	public List<Amiti> getAmiti(){
		return jdbc.query("select * from amiti order by empid", new RowMapper<Amiti>() {

			@Override
			public Amiti mapRow(ResultSet rs, int rowNum) throws SQLException {
				Amiti amiti = new Amiti();
				amiti.setEmpid(rs.getInt("empid"));
				amiti.setEname(rs.getString("ename"));
				amiti.setEgroup(rs.getString("egroup"));
				return amiti;
			}
			
		});
	}
}
