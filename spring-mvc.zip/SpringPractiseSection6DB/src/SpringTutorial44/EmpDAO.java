package SpringTutorial44;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class EmpDAO {

	private NamedParameterJdbcTemplate jdbc = null;

	@Autowired
	public void setDataSource(DataSource datasource) {
		this.jdbc = new NamedParameterJdbcTemplate(datasource);
	}

	private String query;
	private MapSqlParameterSource paramSource = new MapSqlParameterSource();
	
	public Emp getEmp(String ename) {
		
		query="select * from emp where lower(ename)=lower(:ename)";
		paramSource.addValue("ename", ename);
		return jdbc.queryForObject(query, paramSource, new RowMapper<Emp>() {

			@Override
			public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
				Emp emp = new Emp();
				emp.setEmpno(rs.getInt("empno"));
				emp.setEname(rs.getString("ename"));
				emp.setComm(rs.getInt("comm"));
				emp.setSal(rs.getInt("sal"));
				emp.setDeptno(rs.getInt("deptno"));
				emp.setHiredate(rs.getString("hiredate"));
				emp.setMgr(rs.getInt("mgr"));
				emp.setJob(rs.getString("job"));
				return emp;
			}
		});
	}
	public List<Emp> getEmp() {

		query="select * from emp";
		return jdbc.query(query,new RowMapper<Emp>() {

			@Override
			public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
				Emp emp = new Emp();
				emp.setEmpno(rs.getInt("empno"));
				emp.setEname(rs.getString("ename"));
				emp.setComm(rs.getInt("comm"));
				emp.setSal(rs.getInt("sal"));
				emp.setDeptno(rs.getInt("deptno"));
				emp.setHiredate(rs.getString("hiredate"));
				emp.setMgr(rs.getInt("mgr"));
				emp.setJob(rs.getString("job"));
				return emp;
			}
		});
	}

}
