package com.project1.practise;

import java.util.Stack;

public class Class001 {
	
	public static void main(String[] args) {
		
		Stack<Object> stack=new Stack<Object>();
		Class001 obj=new Class001();
		
		System.out.println("neha".compareTo("nea"));
		
		System.out.println("hello");
		
		System.out.println(Integer.MAX_VALUE);
		
		obj.show();
		
	}
	
	public void show() {
		System.out.println("shown");
		return;
	}
	
	Class001(){
		System.out.println("initiated");
		return;
	}
}
