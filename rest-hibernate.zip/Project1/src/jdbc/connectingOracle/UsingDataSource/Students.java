package jdbc.connectingOracle.UsingDataSource;

public class Students {

	private int s_id;
	private String s_name;
	private String a_address;
	@Override
	public String toString() {
		return "Students [s_id=" + s_id + ", s_name=" + s_name + ", a_address=" + a_address + "]";
	}
	public int getS_id() {
		return s_id;
	}
	public void setS_id(int s_id) {
		this.s_id = s_id;
	}
	public String getS_name() {
		return s_name;
	}
	public void setS_name(String s_name) {
		this.s_name = s_name;
	}
	public String getA_address() {
		return a_address;
	}
	public void setA_address(String a_address) {
		this.a_address = a_address;
	}
}
