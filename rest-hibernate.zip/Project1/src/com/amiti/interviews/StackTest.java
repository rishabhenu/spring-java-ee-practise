package com.amiti.interviews;

import java.util.ArrayList;
import java.util.List;

public class StackTest {

	public static void main(String...strings) {
		
		List<Integer> list=new ArrayList<>();
		
		list.add(10);
		list.add(0, 20);
		
		System.out.println(list);
		Stack stack=new Stack();
		
		stack.push("Rishu").push("Neha").push("Anoop").push("Bangalore");
		stack.push("Ishu").push("Dishu").push("Anjali").push("Parul").push("Shivakshi");
		stack.push("hldj").push(488).push(478);
		System.out.println(stack.search("Rishu"));
	}
}
