package com.vskill.internship.languagefundamentals;

//Write the response of code written below :-
public class Main{
    public static void main(String[] args){
        System.out.println("Hello world");
        new Main().printHello();
        return;
    }

    public void printHello(){
        main(new String[10]);
    }
}
