package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.email.ConstantTableI.NotificationType;
import com.email.processor.EmailHelper;
import com.email.processor.EmailServices;
import com.email.processor.MessageAPI;
import com.email.processor.MessageAPIdao;

@org.springframework.stereotype.Controller
public class Controller {

	private static Log log = LogFactory.getLog(Controller.class);

	public Controller() {
	}

	public Controller(MessageAPIdao daoServices, EmailServices emailServices) {
		this.daoServices = daoServices;
		this.emailServices = emailServices;
	}

	private MessageAPIdao daoServices;
	private EmailServices emailServices;

	@RequestMapping(path = "/signup", method = RequestMethod.GET)
	public String createUserPage(HttpServletRequest request, HttpServletResponse response, Model model) {
		return "signup";
	}

	@RequestMapping(path = "/signup", method = RequestMethod.POST)
	public String createUser(HttpServletRequest request, HttpServletResponse response, Model model) {
		String username = request.getParameter("username"), fullName = request.getParameter("fullName"),
				email = request.getParameter("email"), password = request.getParameter("password");
		if (username == null||username.length()<=0) {
			model.addAttribute("signupresult", "username can't be null value");
			return "signup";
		}else if(username.indexOf(' ')!=-1){
			model.addAttribute("username can not contain space");
			return "signup";
		}
		if (fullName == null||fullName.length()<=0) {
			model.addAttribute("signupresult", "Name can't be null");
			return "signup";
		}
		if (email == null||email.length()<=0) {
			model.addAttribute("signupresult", "Email id can't be null value");
			return "signup";
		} else if (!EmailHelper.validateEmailAddress(email)) {
			model.addAttribute("signupresult", "entered email id is not of proper format");
			return "signup";
		}
		if (password == null||password.length()<=0) {
			model.addAttribute("signupresult", "password can't be null value");
			return "signup";
		}
		MessageAPI obj = null;
		try {
			obj = daoServices.getOneUserByEmail(email);
			log.info("checking whether email entered exists already or not");
			if (obj != null) {
				model.addAttribute("signupresult", "This email id is already exist");
				throw new Exception("email already exist");
			}
			log.info("email id doesn't exist already, now checking for username");

			obj = daoServices.getOneUserByUsername(username);

			if (obj != null) {
				model.addAttribute("signupresult", "username is already taken by some other user, please try another");
				throw new Exception("username already exist");
			}
			log.info("username available now inserting data into table");
			daoServices.enterUserDetails(username, fullName, email, password);
			emailServices.sendEmail(NotificationType.ACCOUNT_CREATED, email);
			log.info("new user data inserted in database table");
			log.info("user is informed about account creation via email");
		} catch(SecurityException se) {
			log.error("email not sent "+se.getMessage());
			return "signup";
		}catch (Exception e) {
			log.error(e.getMessage());
			return "signup";
		}
		model.addAttribute("signupsuccess", "Account created successfully. Check email for further details");
		return "signup";
	}

	@RequestMapping(path = "/")
	public String getHome(HttpServletRequest request, HttpServletResponse response, Model model) {
		log.info("email id of " + request.getParameter("username") + " is: "
				+ daoServices.getEmail(request.getParameter("username")));
		try {
			emailServices.sendEmail(NotificationType.LOGIN_ALERT,
					daoServices.getEmail(request.getParameter("username")));
			log.info("user is informed about login via email");
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
		}
		return "index";
	}

	@RequestMapping(path = "/login")
	public String login(HttpServletRequest request, HttpServletResponse response, Model model) {
		if (request.getParameter("error") != null) {
			model.addAttribute("loginerror", "Login failed! Check username and password again");
		}
		return "login";
	}

}
