package com.telusko.rest.resources;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class AlienRepository{

	private Log log = LogFactory.getLog(AlienRepository.class);
	private NamedParameterJdbcTemplate jdbcTemplate=null;
	private BeanPropertySqlParameterSource paramMap=null;

	public List<Alien> getAliens() {
		try {
			log.info("trying to execute jdbc query for complete list of all rows");
			return jdbcTemplate.query("select * from aliens order by id desc", rowMapper);
		}catch(Exception e) {
		log.error(e.getMessage());
		return null;
		}
	}

	public Alien getAliens(int id) {
		try {
			log.info("trying to execute jdbc query for single object");
			paramMap=new BeanPropertySqlParameterSource(new Alien(id,null,null));
			return jdbcTemplate.queryForObject("select * from aliens where id=:id", paramMap, rowMapper);
		}catch(Exception e) {
			log.error(e.getMessage());
			return null;
		}
	}
	
	protected RowMapper<Alien> rowMapper=new RowMapper<Alien>() {
		@Override
		public Alien mapRow(ResultSet rs, int rowNum) throws SQLException {
			return new Alien(rs.getInt("id"),rs.getString("name"),rs.getString("text"));
		}
	};
	
	public AlienRepository() {
		BasicDataSource dataSource=null;
		log.info("trying to setup dataSource");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			dataSource=new BasicDataSource();
			dataSource.setUsername("SYSTEM");
			dataSource.setPassword("password");
			dataSource.setUrl("jdbc:oracle:thin:@localhost:1521:orcl");
			dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
			log.info("dataSource is set down");
		}catch(ClassNotFoundException e) {
			log.error(e.getMessage());
		}catch(Exception e) {
			log.error(e.getMessage());
		}
		this.jdbcTemplate=new NamedParameterJdbcTemplate(dataSource);
	}

	public int createAliens(Alien a) {
		paramMap=new BeanPropertySqlParameterSource(a);
		int rows=0;
		try{
			log.info("try to insert values in the table");
			rows = jdbcTemplate.update("insert into aliens(id,name,text) values(:id,:name,:text)", paramMap);
			log.info(rows+" rows updated");
			return rows;
		}catch(Exception e) {
			log.error(e.getMessage());
			return -1;
		}
	}
}