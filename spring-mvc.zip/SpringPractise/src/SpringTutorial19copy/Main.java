package SpringTutorial19copy;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String args[])
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("SpringTutorial19copy/beans.xml");
		
		HaveResult haveresult=(HaveResult)context.getBean("haveresult");
		
		System.out.println(haveresult);
		
		((ClassPathXmlApplicationContext)context).close();
	}

}
