package com.email;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.email.ConstantTableI.NotificationType;

public final class EmailSubjects {

	private static Log log = LogFactory.getLog(EmailSubjects.class);

	public static String getEmailSubject(NotificationType nType) {
		String result = null;
		switch (nType) {
		case LOGIN_ALERT:
			result = "Login Alert";
			break;
		case ACCOUNT_CREATED:
			result = "Account Created Successfully";
			break;
		default:
			log.error("no specific notification type found: "+nType);
			return null;
		}
		log.info(nType+" type subject is "+result);
		return result;
	}
}
