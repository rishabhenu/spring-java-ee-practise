package com.dao.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


public class RandomClass {
	
	private String name;
	public void setName(String s) {
		name = s;
	}
	public String getName() {
		return name;
	}

}
