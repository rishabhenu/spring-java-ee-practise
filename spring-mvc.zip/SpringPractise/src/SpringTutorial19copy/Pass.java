package SpringTutorial19copy;

public interface Pass {

	public String pass();
}
