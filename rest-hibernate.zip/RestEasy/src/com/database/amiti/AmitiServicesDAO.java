package com.database.amiti;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class AmitiServicesDAO {

	private static final Log log = LogFactory.getLog(AmitiServicesDAO.class);
	private NamedParameterJdbcTemplate jdbcTemplate;

	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	public boolean insertAmitiTable(Amiti amiti) {
		BeanPropertySqlParameterSource paramMap=new BeanPropertySqlParameterSource(amiti);
		try{
			return 1==jdbcTemplate.update("insert into amiti(empid,ename,egroup) values(:empid,:ename,:egroup)", paramMap);
		}catch(Exception e){
			log.error(e);
			return false;
		}
	}
	
	public Amiti getAmitiTableById(int empid) {
		Amiti amiti = new Amiti();
		amiti.setEmpid(empid);
		BeanPropertySqlParameterSource paramMap = new BeanPropertySqlParameterSource(amiti);
		return jdbcTemplate.queryForObject("select * from amiti where empid=:empid", paramMap, rowMapper);
	}

	public List<Amiti> getAmitiTable() {
		return jdbcTemplate.query("select * from amiti order by empid desc", rowMapper);
	}

	private final RowMapper<Amiti> rowMapper = new RowMapper<Amiti>() {
		@Override
		public Amiti mapRow(ResultSet rs, int rowNum) throws SQLException {
			Amiti amiti = new Amiti();
			amiti.setEmpid(rs.getInt("empid"));
			amiti.setEgroup(rs.getString("egroup"));
			amiti.setEname(rs.getString("ename"));
			return amiti;
		}
	};
	
	public boolean updateTimer(String vin) {
//		BasicDataSource dataSource = new BasicDataSource();
//		dataSource.setUrl("jdbc:oracle:thin:@t-aucscan-101.adesa.com:1521/AUCS.adesa.com");
//		dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
//		dataSource.setUsername("adappl");
//		dataSource.setPassword("adappl");
//		NamedParameterJdbcTemplate jdbc = new NamedParameterJdbcTemplate(dataSource);
		Map<String,String> paramMap = new HashMap<String, String>();
		paramMap.put("vin", vin);
		try{
			int i = jdbcTemplate.update("update auctions set end_time=sysdate,resolve_time=sysdate where vehicle_id=(select vehicle_id from vehicles where vin = :vin)", paramMap);
			log.info("i = "+i);
			int j = jdbcTemplate.update("update vehicles_timer_events set event_datetime=sysdate where vehicle_id=(select vehicle_id from vehicles where vin = :vin)", paramMap);
			log.info("j = "+j);
			return i==1&&j==1;
		}catch(Exception e) {
			System.out.println("exception caught"+e);
		}
		return false;
		
	}
}
