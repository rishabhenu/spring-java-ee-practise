package SpringTutorial29;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String args[])
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("/SpringTutorial29/beans.xml");
		
		Combined combined=(Combined)context.getBean("combined");
		
		System.out.println(combined);
		
		((ClassPathXmlApplicationContext)context).close();
	}

}
