package com.hibernate.database;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="amiti")
public class Aliens {
	
	@Id
	@Column(name = "empid")
	private int id;
	@Column(name="ename")
	private String name;
	@Column(name="egroup")
	private String text;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	@Override
	public String toString() {
		return "Aliens [id=" + id + ", name=" + name + ", text=" + text + "]";
	}
}
