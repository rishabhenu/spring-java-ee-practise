package practise;

import org.springframework.context.*;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Main {
	
	public static void main(String[] args)
	{
		ApplicationContext context = new FileSystemXmlApplicationContext("src/practise/beansFile/beans.xml");
		
		Person person=(Person)context.getBean("person");
		person.speak();
		
		System.out.println("person "+person);
		
		Person person1=(Person)context.getBean("person1");
		System.out.println("person1 "+person1);
		
		Address address = (Address)context.getBean("address");
		System.out.println(address);
		
		((FileSystemXmlApplicationContext)context).close();
	}

}
