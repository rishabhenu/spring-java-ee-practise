package com.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ece.ECE34;
import com.ece.ECE34DAO;
import com.login.Login;

@Controller
public class MainController {

	private ECE34DAO ecedao = null;

	@Resource(name = "ece34dao")
	public void setEcedao(ECE34DAO ecedao) {
		this.ecedao = ecedao;
	}

	@RequestMapping(value = "/")
	public String login(Model model, Login login, HttpServletRequest request, HttpServletResponse response) {
		model.addAttribute("user",request.getRemoteUser());
		System.out.println(request.getAuthType());
		model.addAttribute("hello", "hello");
		return "home";
	}

	@RequestMapping(value = "ece34")
	public String getECE34(Model model, HttpServletRequest request, HttpServletResponse response) {
		model.addAttribute("roll", new ECE34());
		if(request.getParameter("rollno")!=null){
			try {
				if(request.getParameter("rollno").compareTo("")==0) {
					model.addAttribute("ece34table", ecedao.getTable());
					return "ece34";
				}
				List<ECE34> ece = ecedao.getTable(Integer.parseInt(request.getParameter("rollno")));
				if (ece.size() == 0) {
					model.addAttribute("ece34table", "No record found for entered rollno");
					return "ece34";
				} else {
					model.addAttribute("ece34table", ece);
				}

			} catch (NumberFormatException e) {
				model.addAttribute("ece34table", "enter valid rollno");
			}
			return "ece34";
		}
		else{
			model.addAttribute("ece34table", ecedao.getTable());
			return "ece34";
		}
	}
}
