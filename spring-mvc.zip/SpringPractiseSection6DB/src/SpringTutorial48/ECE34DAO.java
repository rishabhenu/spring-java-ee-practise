package SpringTutorial48;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class ECE34DAO {

	private NamedParameterJdbcTemplate jdbc=null;
	
	@Autowired
	public void setDataSource(DataSource datasource) {
		this.jdbc=new NamedParameterJdbcTemplate(datasource);
	}
	
//	@Transactional
	public int[] createECE34(List<ECE34> ece34) {	
		SqlParameterSource batchValues[] = SqlParameterSourceUtils.createBatch(ece34.toArray());
		return jdbc.batchUpdate("insert into ECE34(rollno,name,address) values(:rollno,:name,:address)", batchValues);
	}

	public List<ECE34> getECE34() {
		return jdbc.query("select * from ece34 order by rollno desc", new RowMapper<ECE34>() {

			@Override
			public ECE34 mapRow(ResultSet rs, int rowNum) throws SQLException {
				ECE34 ece=new ECE34();
				ece.setRollno(rs.getString("rollno"));
				ece.setName(rs.getString("name"));
				ece.setAddress(rs.getString("address"));
				return ece;
			}			
		});
	}
	
}
