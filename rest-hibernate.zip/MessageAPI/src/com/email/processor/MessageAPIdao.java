package com.email.processor;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class MessageAPIdao {
	private static Log log=LogFactory.getLog(MessageAPIdao.class);
	
	private NamedParameterJdbcTemplate jdbcTemplate;
	
	public MessageAPIdao(DataSource dataSource) {
		this.jdbcTemplate=new NamedParameterJdbcTemplate(dataSource);
	}
	
	public MessageAPI getOneUserByEmail(String email) {
		MapSqlParameterSource paramMap=new MapSqlParameterSource("email", email);
		try{
			MessageAPI obj = jdbcTemplate.queryForObject("select * from messageapi where email=:email", paramMap, rowMapper);
			return (obj!=null)?obj:null;
		}catch(Exception e) {
			return null;
		}
	}
	public MessageAPI getOneUserByUsername(String username) {
		MapSqlParameterSource paramMap=new MapSqlParameterSource("username", username);
		try{
			MessageAPI obj = jdbcTemplate.queryForObject("select * from messageapi where username=:username", paramMap, rowMapper);
			return (obj!=null)?obj:null;
		}catch (Exception e) {
			return null;
		}
	}
	
	public int enterUserDetails(String username,String fullName,String email,String password) {
		if(username==null||username.length()<=0) {
			log.error("username is null");return -1;
		}
		if(fullName==null||fullName.length()<=0) {
			log.error("fullName is null");return -1;
		}
		if(!EmailHelper.validateEmailAddress(email)) {
			log.error("email id is not validated");return -1;
		}
		try {
			MapSqlParameterSource paramMap=new MapSqlParameterSource();
			paramMap.addValue("username", username);
			paramMap.addValue("full_name", fullName);
			paramMap.addValue("email", email);
			paramMap.addValue("password", password);
			paramMap.addValue("enabled", 1);
			paramMap.addValue("authority", "USER");
			return jdbcTemplate.update("insert into messageapi(username,full_name,email,password,enabled,authority) values(:username,:full_name,:email,:password,:enabled,:authority)", paramMap);
		}catch(DuplicateKeyException dke){
			log.error("duplicate record found");
		}catch(Exception e) {
			log.error(e);
		}
		return -1;
	}
	
	public String getEmail(String username) {
		MapSqlParameterSource paramMap=new MapSqlParameterSource();
		paramMap.addValue("username", username);
		MessageAPI obj=jdbcTemplate.queryForObject("select * from messageapi where username=:username", paramMap , rowMapper);
		if(obj!=null) {
			log.info("found email: "+obj.getEmail()+" for username: "+username);
			return obj.getEmail();
		}
		else {
			log.warn("no data found for username: "+username);
			return null;
		}
	}
	
	protected RowMapper<MessageAPI> rowMapper= new RowMapper<MessageAPI>() {
		@Override
		public MessageAPI mapRow(ResultSet rs, int rowNum) throws SQLException {
			return new MessageAPI(rs.getString("username"), rs.getString("full_name"), rs.getString("email"), rs.getString("password"));
			
		}
	};
}
