import java.math.BigInteger;

public class FactorialUsingBigInteger {
	
	public static void main(String...strings) {
		BigInteger bi = new BigInteger("1");
		for(int i = 1; i<=100; i++) {
			bi = bi.multiply(BigInteger.valueOf(i));
		}
		System.out.println(bi);
	}

}
