package SpringTutorial29;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Combined {
	
	private A a;
	
	@Autowired
	@Qualifier("classb")
	private I i;
	
	private B b;
	
	@Resource
	public void setA(A a)
	{
		this.a=a;
	}
	
	@Resource(name="classbcopy")
	public void setB(B b)
	{
		this.b=b;
	}
	
	@Override
	public String toString() {
		return "Combined [a=" + a + ", i=" + i + ", b=" + b + "]";
	}

}
