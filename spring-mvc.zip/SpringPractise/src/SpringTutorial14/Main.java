package SpringTutorial14;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Main {
	
	public static void main(String args[])
	{
		ApplicationContext context=new FileSystemXmlApplicationContext("/src/SpringTutorial14/beans.xml");
		
		FruitBasket basket = (FruitBasket) context.getBean("basket");
		
		System.out.println(basket);
		
		basket.addFruits("Banana");
		
		System.out.println(basket);
		
		((FileSystemXmlApplicationContext)context).close();
	}

}
