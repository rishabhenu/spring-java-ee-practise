package spring7.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import spring7.students.Students;
import spring7.students.StudentsDAO;

@Controller
public class StudentsController {

	private StudentsDAO studentsdao;

	@Resource(name="studentsDao")
	public void setStudentsdao(StudentsDAO studentsdao) {
		this.studentsdao = studentsdao;
	}

	@RequestMapping("/")
	public String getHome(Model model) {

		List<Students> students = studentsdao.getStudents();

		model.addAttribute("students", students);
		model.addAttribute("job", "software developer");
		model.addAttribute("company", "Amiti software Technology");

		return "home";
	}

	@RequestMapping("/students")
	public String getStudents(Model model) {

		List<Students> students = studentsdao.getStudents();

		model.addAttribute("students", students);

		return "students";
	}

	// @RequestMapping("/")
	public ModelAndView getModel() {

		ModelAndView model = new ModelAndView("home");
		Map<String, Object> list = model.getModel();
		list.put("job", "Software Developer Trainee");
		list.put("company", "Amiti Software Technology");
		return model;
	}
}
