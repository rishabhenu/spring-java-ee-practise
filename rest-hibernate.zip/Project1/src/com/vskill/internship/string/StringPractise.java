package com.vskill.internship.string;

public class StringPractise {
	int a[]=new int[0];
	static final int aa=10;
	public static void main(String...strings) throws Exception{
		StringPractise obj=new StringPractise();
//		System.out.println(obj.a.length);		
		
		
//		Find error in below code:-
		try {
			throw new ArithmeticException();
		}catch(Throwable t) {
			System.out.println("Exception catched");
		}
	}
//	Exception catched
//	Exception catched
}
