package com.project1.practise.enums;

public enum Level {

	high(10),
	medium(7),
	low(5);
	public final int level;
	
	Level(int l){
		this.level=l;
	}
	
}
