package com.imola.auctionenginecache;

public class A implements I{

	private I.ConditionType conditionType;	
	public I.ConditionType getConditionType() {return conditionType.FAST;}
	public void setConditionType(I.ConditionType conditionType) {
		this.conditionType = conditionType;
	}

	public String getRank() {
		
		switch(getConditionType()) {
		case SLOW:
			return "Bike is running slowly";
		case MEDIUM:
			return "Speed of bike is under control";
		case FAST:
			return "bike is overspeeded";
		default:
			break;
		}
		
		return null;
	}
}
