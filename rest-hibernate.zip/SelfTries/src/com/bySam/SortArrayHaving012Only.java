package com.bySam;

public class SortArrayHaving012Only {

	public static void main(String... strings) {
		int a[] = { 0,1,2,0,2,1,1,0,2,1,2,0,2,0,1,2,1,0 };

		int result[] = new int[a.length];
		int zero = 0, one = 0, two = a.length - 1;

		for (int i = 0; i < a.length; i++) {
			if (a[i] == 0) {
				if(result[zero]==1) {result[one]=1;one++;result[zero] = 0;zero++;}
				else{
					result[zero] = 0;
					zero++;one++;
				}
			}
			for (int j : result) {System.out.print(j+" ");}
			System.out.println("hello "+ zero+" "+one+" "+two);
			
			if (a[i] == 2) {
				result[two] = 2;
				two--;
			}
			for (int j : result) {System.out.print(j+" ");}
			System.out.println("hello "+zero+" "+one+" "+two);
			
			if (a[i] == 1) {
				if(one>zero) {
					result[one] = 1;
					one++;
				}else if(one==zero&&one!=0) {
					result[one]=1;
					one++;
				}else if(one==zero&&one==0) {
					result[one]=1;one++;
				}
			}
			for (int j : result) {System.out.print(j+" ");}
			System.out.println("hello "+zero+" "+one+" "+two);
		}
		System.out.print("[");for (int j : result) {System.out.print(j+",");}System.out.println("]");
		System.out.println("working fine");
	}
}
