package hackerrank.arraylist;

import java.util.Scanner;

public class InputQueries {

	public static void main(String... strings) {

		// scanning no of lines
		Scanner scann = new Scanner(System.in);
		System.out.println("enter value of n i.e. no of input lines");
		int n = scann.nextInt();
		// scann.close();

		// scanning input lines
		System.out.println("enter values in the lines seperated by single space");
		Scanner scanline = new Scanner(System.in);
		String inputlines[] = new String[n];
		for (int i = 0; i < n; i++) {
			inputlines[i] = scanline.nextLine();
		}

		// scanning no of queries
		System.out.println("enter value of n i.e. no of queries");
		scann = new Scanner(System.in);
		n = scann.nextInt();

		// scanning queries
		System.out.println("enter queries");
		Scanner scanqueries = new Scanner(System.in);
		String queries[] = new String[n];
		for (int i = 0; i < n; i++) {
			queries[i] = scanqueries.nextLine();
		}

		// printing result
		int x = 0, y = 0, result = 0;
		for (int i = 0; i < n; i++) {
			try {
				x = Integer.parseInt(queries[i].split(" ")[0]);
				y = Integer.parseInt(queries[i].split(" ")[1]);

				 if (y > Integer.parseInt(inputlines[x-1].split(" ")[0])) {
				 throw new ArrayIndexOutOfBoundsException();
				 }

				result = Integer.parseInt(inputlines[x - 1].split(" ")[y]);
				System.out.println(result);

			} catch (ArrayIndexOutOfBoundsException e) {
				System.out.println("Error!");
			} catch (Exception e) {
				System.out.println("exception thrown");
			}
		}
	}
}
//5
//5 41 77 74 22 44
//1 12
//4 37 34 36 52
//0
//3 20 22 33
//5
//1 3
//3 4
//3 1
//4 3
//5 5