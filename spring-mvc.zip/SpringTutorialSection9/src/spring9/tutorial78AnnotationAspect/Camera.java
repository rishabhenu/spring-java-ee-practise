package spring9.tutorial78AnnotationAspect;

public class Camera {

	public void photo() {
		System.out.println("photo clicked");
	}
}
