package spring9.tutorial77;

import org.springframework.stereotype.Component;

@Component
public class Camera {	
	
	public void photo() {
		System.out.println("photo clicked");
	}
}
