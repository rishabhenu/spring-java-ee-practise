package com.dao.services;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


public class RandomCal {
	
	private String name;
	private RandomClass randomClass;
	
	public RandomClass getRandomClass() {
		return randomClass;
	}

	public void setRandomClass(RandomClass randomClass) {
		this.randomClass = randomClass;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "RandomCal [name=" + name + ", randomClass=" + /**randomClass*/  "]";
	}
}
