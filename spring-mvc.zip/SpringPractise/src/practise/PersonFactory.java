package practise;

public class PersonFactory {
	
	public Person createPerson(int id,String name)
	{
		System.out.println("object created in personfactory class");
		return new Person(110,"Anoop");
	}

}
