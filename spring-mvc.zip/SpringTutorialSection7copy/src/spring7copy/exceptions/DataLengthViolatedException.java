package spring7copy.exceptions;

public class DataLengthViolatedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5683202426904910448L;

	@Override
	public String getMessage() {
		return "uuuuooooo............data not inserted,,,,, \n "
				+ "might be you are entering some of the field i.e. too long and not acceptable.... "
				+ "rollno can't exceed 8 digits and name or address can't exceed 20 characters";
	}
}
