package spring7copy.exceptions;

public class DataNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2471565231975255631L;

	@Override
	public String getMessage() {
		return "No matching record found for updation and hence data not updated";
	}
}
