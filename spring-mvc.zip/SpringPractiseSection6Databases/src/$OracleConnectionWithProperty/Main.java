package $OracleConnectionWithProperty;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main{
	
	public static void main(String args[]) throws SQLException {
		
		String classpath="$OracleConnectionWithProperty/beans.xml";
		
		ApplicationContext context=new ClassPathXmlApplicationContext(classpath);
		
		JDBCwithProperty oracle=(JDBCwithProperty)context.getBean("oracle");
		
		((ClassPathXmlApplicationContext)context).close();
		
		String user=oracle.getUser();
		String password=oracle.getPassword();
		
		String url="jdbc:oracle:thin:@localhost:1521:orcl";
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {System.out.println("Class not found");}
		
		Connection connection = DriverManager.getConnection(url, user, password);
		
		Statement st = connection.createStatement();
		
		ResultSet rs = st.executeQuery("select * from students");
		
		while(rs.next()) {
			System.out.println(rs.getObject(1)+" "+rs.getObject(2)+" "+rs.getObject(3));
		}		
	}
}
