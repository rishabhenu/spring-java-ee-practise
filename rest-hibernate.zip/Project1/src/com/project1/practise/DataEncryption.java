package com.project1.practise;

import java.util.Base64;

import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import org.springframework.beans.factory.annotation.Required;

public class DataEncryption {
	
	protected static final String ENCRYPTION_ALGO = "DES";
	protected SecretKey           key;

	static final String CHARSET = "UTF-8"; 
	
	@Required
	public SecretKey setKey(String password) throws Exception{

		key = SecretKeyFactory.
			    getInstance(ENCRYPTION_ALGO).
			        generateSecret(new DESKeySpec(password.getBytes()));
		return key;
	}
	
	public static void main(String...strings) throws Exception {		
		DataEncryption obj=new DataEncryption();
		
		SecretKey key=obj.setKey("rishusharm");
		
		System.out.println(key.getAlgorithm());
		
		System.out.println(obj.encoded(key));
	}
	
	public String encoded(SecretKey secretKey) {
		return Base64.getEncoder().encodeToString(secretKey.getEncoded());
	}
}
