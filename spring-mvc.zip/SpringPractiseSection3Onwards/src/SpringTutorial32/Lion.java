package SpringTutorial32;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Lion {
	
	@Autowired
	private Junglee junglee;
	
	private String name;
	
	private String food;
	
	@Autowired
	public void setName(@Value("Rishabh")String name) {
		this.name=name;
	}
	
	@Autowired
	public void setFood(@Value("Deer")String food) {
		this.food=food;
	}
	
	@Override
	public String toString() {
		return "Lion [junglee=" + junglee + ", name=" + name + ", food=" + food + "]";
	}
}
