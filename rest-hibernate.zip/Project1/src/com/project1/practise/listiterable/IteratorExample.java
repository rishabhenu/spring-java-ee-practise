package com.project1.practise.listiterable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IteratorExample<T> implements Iterable<T>{

	private List<T> myList=new ArrayList<>();
	
	public void add(T val) {
		myList.add(val);
	}
	
	@Override
	public Iterator<T> iterator() {
		return new CustomIterable<>(myList);
	}

	public class CustomIterable<E> implements Iterator<E>{
		
		int index=0;
		List<E> list;
		public CustomIterable(List<E> list) {
			this.list=list;
		}

		@Override
		public boolean hasNext() {
			if(list.size()>index)return true;
			return false;
		}

		@Override
		public E next() {
			E val=list.get(index);
			index++;
			return val;
		}
		
	}
}
