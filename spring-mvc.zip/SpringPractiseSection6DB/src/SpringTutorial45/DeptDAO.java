package SpringTutorial45;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class DeptDAO {
	private NamedParameterJdbcTemplate jdbc;
	
	@Autowired
	public void setDataSource(DataSource datasource) {
		this.jdbc=new NamedParameterJdbcTemplate(datasource);
	}
	
	public boolean deleteDept(int deptno) {

		MapSqlParameterSource param=new MapSqlParameterSource("deptno",deptno);
		return jdbc.update("delete from dept where deptno=:deptno", param)==1;
	}
	
	public void updateDept(String query) {
		
	}
	
	public List<Dept> getDept() {
		return this.jdbc.query("select * from dept", new RowMapper<Dept>() {
			@Override
			public Dept mapRow(ResultSet rs, int rowNum) throws SQLException {
				Dept dept=new Dept();
				dept.setDeptno(rs.getInt("deptno"));
				dept.setDname(rs.getString("dname"));
				dept.setLoc(rs.getString("loc"));
				return dept;
			}
			
		});
	}

}
