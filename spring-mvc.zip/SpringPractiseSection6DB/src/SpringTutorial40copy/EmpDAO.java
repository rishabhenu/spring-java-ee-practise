package SpringTutorial40copy;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class EmpDAO {
	private String query="select * from emp";
	
	private JdbcTemplate jdbc=null;
	
	@Autowired
	public void setDataSource(DataSource datasource) {
		this.jdbc=new JdbcTemplate(datasource);
	}
	
	public List<Emp> getEmp(){
		return jdbc.query(query, this.rowMapper);
	}
	
	private RowMapper<Emp> rowMapper=new RowMapper<Emp>() {

		@Override
		public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
			Emp emp=new Emp();
			emp.setEmpno(rs.getInt("empno"));
			emp.setEname(rs.getString("ename"));
			emp.setComm(rs.getInt("comm"));
			emp.setSal(rs.getInt("sal"));
			emp.setDeptno(rs.getInt("deptno"));
			emp.setHiredate(rs.getString("hiredate"));
			emp.setMgr(rs.getInt("mgr"));
			emp.setJob(rs.getString("job"));
			return emp;
		}
		
	};

}
