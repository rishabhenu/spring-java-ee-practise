package hackersrank.array;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class ArrayHighestSum {



    private static final Scanner scanner = new Scanner(System.in);
    static int n=6;
    public static void main(String[] args) {
        int[][] arr = new int[6][6];

        System.out.println("enter elements row wise");
        for (int i = 0; i < 6; i++) {
            String[] arrRowItems = scanner.nextLine().trim().split(" ");
            scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

            for (int j = 0; j < 6; j++) {
                int arrItem = Integer.parseInt(arrRowItems[j]);
                arr[i][j] = arrItem;
            }
        }

        scanner.close();
        int temp=0;
        int result=Integer.MIN_VALUE;
        boolean b=false;
        for(int i=0;i<=n-3;i++)
        {
            for(int j=0;j<=n-3;j++)
            {
            	temp=0;
            	for(int ii=i;ii<i+3;ii++)
            	{
            		for(int jj=j;jj<j+3;jj++)
            		{
            			b=((ii==i+1)&&(jj==j||jj==j+2));
            			if(!b) {temp+=arr[ii][jj];}//System.out.print(ii+""+jj+" ");}
            		}
            	}
//            	System.out.println();
            	if(result<temp) {result=temp;}
//            	System.out.println(result+"result "+temp+"temp");
            }
        }
    }
}

