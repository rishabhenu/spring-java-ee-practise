package com.project1.practise;

import java.io.IOException;
import java.util.logging.Level;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LoggerExample {
	private static final Log LOGGER = LogFactory.getLog(LoggerExample.class);

	public static void main(String[] args) throws SecurityException, IOException {
		
		LOGGER.info("Logger Name: " + LOGGER.getClass());
		LOGGER.warn("Can cause ArrayIndexOutOfBoundsException");
		
		int[] a = { 1, 2, 3, 4};
		int index = 4;
		if(index>=a.length) {
			LOGGER.warn("index is set to " + index);
		}
		try {
			System.out.println(a[index]);
		} catch (ArrayIndexOutOfBoundsException ex) {
			LOGGER.error("Exception occur", ex);
		}
		LOGGER.info("PROGRAM COMPLETED");
		LOGGER.fatal("bass rehan de hun");
		
	}
}