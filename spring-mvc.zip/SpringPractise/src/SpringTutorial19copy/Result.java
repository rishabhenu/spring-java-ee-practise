package SpringTutorial19copy;

public class Result implements Pass,Fail {

	public String pass()
	{
		return "You passed";
	}
	
	public String fail()
	{
		return "You failed";
	}

	@Override
	public String toString() {
		return "Result [pass()=" + pass() + ", fail()=" + fail() + "]";
	}
	
	
}
