package spring8.spring8;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class Spring8DAO {

	private NamedParameterJdbcTemplate jdbc;
	
	@Resource(name="dataSource")
	public void setDataSource(DataSource datasource)
	{
		this.jdbc=new NamedParameterJdbcTemplate(datasource);
	}
	
//	fetch complete table
	public List<Spring8> getComplete()
	{
		return jdbc.query("select * from spring8 order by id desc", new RowMapper<Spring8>() {
			
			@Override
			public Spring8 mapRow(ResultSet rs, int rowNum) throws SQLException {
				Spring8 spring=new Spring8();
				spring.setId(rs.getInt("id"));
				spring.setName(rs.getString("name"));
				spring.setText(rs.getString("text"));
				return spring;
			}
		});
	}

//	insert data into spring8 table
	public int insertSpring8(Spring8 spring)
	{
		BeanPropertySqlParameterSource param=new BeanPropertySqlParameterSource(spring);
		
		return jdbc.update("insert into spring8(id,name,text) values(:id,:name,:text)", param);
	}
}
