package com.vskill.internship.io;

import java.io.File;

public class InputFileStreamPractise {

	public static void main(String...strings) throws Exception{
		File file=new File("C:/Users/amiti/Downloads/demodemo.txt");
		
		System.out.println(file.getAbsolutePath());
	}
}
