package SpringTutorial18;

public class Logger {
	
	private LogWriter logwriter;
	private FileWriter filewriter;
	private ConsoleWriter consolewriter;
	
	public void setConsolewriter(ConsoleWriter consolewriter)
	{
		this.consolewriter=consolewriter;
	}
	
	public void setFilewriter(FileWriter filewriter)
	{
		this.filewriter=filewriter;
	}
	
	public void setLogwriter(LogWriter logWriter)
	{
		this.logwriter=logWriter;
	}

	@Override
	public String toString() {
		return "Logger [logwriter=" + logwriter + ", filewriter=" + filewriter + ", consolewriter=" + consolewriter
				+ "]";
	}

}
