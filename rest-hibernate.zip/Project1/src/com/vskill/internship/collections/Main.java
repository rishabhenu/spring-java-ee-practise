package com.vskill.internship.collections;

public class Main {
	
	public static void main(String...strings) throws ClassNotFoundException {
		
		
		System.out.println("run perfectly");
	}
	
}
