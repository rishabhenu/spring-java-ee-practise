package com.vskill.internship.io;

public class Main {
	
	static System system;
	
	public static void main(String...strings) {
		system.out.println("Hello World");
	}
}
