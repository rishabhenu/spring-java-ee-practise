package com.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class SpringDAO {

	Log log=LogFactory.getLog(SpringDAO.class);

	private NamedParameterJdbcTemplate jdbc;

	public void setDataSource(DataSource dataSource) {
		try{
			log.info("trying to set datasource");
			this.jdbc = new NamedParameterJdbcTemplate(dataSource);
			log.info("dataSource is set down");
		}catch(Exception e) {
			log.error("Couldn't set datasource "+e.getMessage());
		}
	}

	/* here is the method that returns complete list of all the rows in table*/
	public List<Spring8> getSpringTable() {
		try{
			log.info("trying to execute query");
			return jdbc.query("select * from spring8", new RowMapper<Spring8>() {

			@Override
			public Spring8 mapRow(ResultSet rs, int rowNum) throws SQLException {
				Spring8 spring = new Spring8();
				spring.setId(rs.getInt("id"));
				spring.setName(rs.getString("name"));
				spring.setText(rs.getString("text"));
				log.info("query execution succeeded");
				return spring;
			}
		});
		}catch(Exception e) {
			log.error("couldn't process SQL query "+e.getCause());
			return null;
		}
	}
	
	private Spring8 spring;
	 
	public void setSpring8(Spring8 spring) {
		log.info("Spring8 class loaded");
		this.spring = spring;}
	public Spring8 getSpring8() {return spring;}
}
