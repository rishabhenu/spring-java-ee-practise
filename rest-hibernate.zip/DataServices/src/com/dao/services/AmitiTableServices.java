package com.dao.services;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

public class AmitiTableServices {

	private static String url = "http://127.0.0.1:8080/RestEasy-1/rest/table";

	private static RestTemplate restTemplate;

	private final static Log logger = LogFactory.getLog(AmitiTableServices.class);

	public static RandomCal getVehicleRecommendation() {
		RandomCal resp = null;
		restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<RandomCal> response = restTemplate.exchange(url, HttpMethod.GET, entity, RandomCal.class);
		resp = response.getBody();
		return resp;
	}
	
	public static String[] getVehicle(){
		String resp = null;
		restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<String[]> response = restTemplate.exchange(url, HttpMethod.GET,entity,new ParameterizedTypeReference<String[]>() {
		});
		return response.getBody();
	}
	
	public static void main(String args[]) {
		AmitiTableServices amiti = new AmitiTableServices();
//		RandomCal randomCal = AmitiTableServices.getVehicleRecommendation();
//		System.out.println(randomCal);
		for(String s : getVehicle()){
			System.out.println(s);
		}
		System.out.println("working");
	}
}
