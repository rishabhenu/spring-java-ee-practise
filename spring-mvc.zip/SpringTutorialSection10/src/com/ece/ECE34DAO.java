package com.ece;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class ECE34DAO {

	private NamedParameterJdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate=new NamedParameterJdbcTemplate(dataSource);
	}
	
	public List<ECE34> getTable(int rollno) {
		MapSqlParameterSource param=new MapSqlParameterSource();
		param.addValue("rollno", rollno);
		List<ECE34> ecelist= jdbcTemplate.query("select * from ece34 where rollno=:rollno", param,new RowMapper<ECE34>() {

			@Override
			public ECE34 mapRow(ResultSet rs, int rowNum) throws SQLException {
				ECE34 ece=new ECE34();
				ece.setRollno(rs.getInt("rollno"));
				ece.setName(rs.getString("name"));
				ece.setAddress(rs.getString("address"));
				return ece;
			}
		});
		return ecelist;
	}
	
	public List<ECE34> getTable(){
		return jdbcTemplate.query("select * from ece34 order by rollno desc", new RowMapper<ECE34>() {

			@Override
			public ECE34 mapRow(ResultSet rs, int rowNum) throws SQLException {
				ECE34 ece=new ECE34();
				ece.setRollno(rs.getInt("rollno"));
				ece.setName(rs.getString("name"));
				ece.setAddress(rs.getString("address"));
				return ece;
			}
			
		});
	}
	
}
