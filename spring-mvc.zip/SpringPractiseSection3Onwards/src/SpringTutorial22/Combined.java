package SpringTutorial22;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Combined {
	
	private A a;
	
	@Autowired
	@Qualifier("im")
	private I i;
	
	@Autowired
	private B b;
	
	@Autowired(required=false)
	public void setA(A a)
	{
		this.a=a;
	}
	
	public void setB(B b)
	{
		this.b=b;
	}
	
	@Override
	public String toString() {
		return "Combined [a=" + a + ", i=" + i + ", b=" + b + "]";
	}

}
