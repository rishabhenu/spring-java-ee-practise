package com.telusko.rest.resources;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Alien {

	public Alien() {}
	public Alien(int id, String name, String text) {
		// TODO Auto-generated constructor stub
		this.id=id;this.name=name;this.text=text;
	}
	private String name;
	private int id;
	private String text;
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getid() {
		return id;
	}
	public void setid(int id) {
		this.id = id;
	}
}
