package spring7copy.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

import spring7copy.ece34.ECE34;
import spring7copy.ece34.ECE34DAO;
import spring7copy.exceptions.DataNotFoundException;

@Controller
public class MainController {

	private ECE34DAO ece34dao;

//	creating ECE34DAO object from bean
	@Resource(name = "ece34dao")
	public void setEce34dao(ECE34DAO ece) {
		this.ece34dao = ece;
	}

//	homepage
	@RequestMapping("/")
	public String showHome(Model model) {
		model.addAttribute("tablenames", "Hello select any option to perform accordingly");
		return "home";
	}

//	showing all records in the table
	/*@RequestMapping("/ece34table")
	public String getECE34(ECE34 ece,Model model) {
		List<ECE34> listece34 = ece34dao.getCompleteTable();
		model.addAttribute("ece34table", listece34);
		return "ece34table";
	}*/

//	inserting values to ece34 table
	@RequestMapping("/createece34")
	public String createECE34(@Valid ECE34 ece, BindingResult result, Model model) {
		System.out.println("createece34 " + ece);
		if (!result.hasErrors()) {
			if (ece.getRollno() > 0) {
				try {
//					if(ece.getName().length()>20||ece.getAddress().length()>20||ece.getRollno()>99999999) {
//						throw new DataLengthViolatedException();
//					}
					ece34dao.insertECE34(ece);
					model.addAttribute("sqlresult", "Values inserted successfully");
					List<ECE34> listece = ece34dao.getCompleteTable();
					model.addAttribute("fulltable", listece);
				}
//				catch(DataLengthViolatedException e) {
//					model.addAttribute("sqlresult",e.getMessage());
//				}
				catch (Exception e) {
					System.out.println(e.getMessage());
					model.addAttribute("sqlresult", "duplicate rollno not allowed, data not inserted");
				}
				List<ECE34> listece = ece34dao.getCompleteTable();
				model.addAttribute("fulltable", listece);
				return "ece34created";
			} else {
				return "createece34";
			}
		} else {
			model.addAttribute("sqlresult",
					"uuuuooooo............data not inserted,,,,, \n "
							+ "might be you are entering some of the field i.e. too long and not acceptable.... "
							+ "rollno can't exceed 8 digits and name or address can't exceed 20 characters");
		}
		return "ece34created";
	}

//	get created or updated result
	@RequestMapping("/ece34created")
	public String ece34Created(ECE34 ece, Model model) {
		model.addAttribute("sqlresult","Here you go........");
		List<ECE34> listece = ece34dao.getCompleteTable();
		model.addAttribute("fulltable", listece);
		return "ece34created";
	}

//	updating existing record
	@RequestMapping("/updateece34")
	public String updateECE34(@Valid ECE34 ece, BindingResult result, Model model) {
		if (!result.hasErrors()) {
			System.out.println("no error");
			if (ece.getRollno() > 0) {
				System.out.println("ece.getrollno > 0 " + (ece.getRollno() > 0));
				try {
					int rows = ece34dao.updateECE34(ece);
					if (rows == 0) {
						throw new DataNotFoundException();
					}
					List<ECE34> listece = ece34dao.getCompleteTable();
					model.addAttribute("fulltable", listece);
					model.addAttribute("sqlresult", "Data updated successfully");
					return "ece34created";
				} catch (DataNotFoundException e) {
					System.out.println(e.getMessage());
					model.addAttribute("sqlresult", e.getMessage());
				} catch (Exception e) {
					System.out.println(e.getMessage());
					model.addAttribute("sqlresult",
							"Maximum characters in name and address can be 20,try again data not updated");
				}
				List<ECE34> listece = ece34dao.getCompleteTable();
				model.addAttribute("fulltable", listece);
				return "ece34created";
			} else {
				return "updateece34";
			}
		} else {
			model.addAttribute("sqlresult",
					"uuuuooooo............data not updated,,,,, \n "
							+ "might be you are entering rollno i.e. too long and not acceptable.... "
							+ "rollno can't exceed 8 digits");
		}
		return "ece34created";
	}

//	deleting all null values
	@RequestMapping("/erasenull")
	public String eraseNull(ECE34 ece34, Model model) {
		model.addAttribute("sqlresult","Here you go..........Null values deleted");
		ece34dao.deleteNull(ece34);
		model.addAttribute("fulltable",ece34dao.getCompleteTable());
		return "ece34created";
	}
}
