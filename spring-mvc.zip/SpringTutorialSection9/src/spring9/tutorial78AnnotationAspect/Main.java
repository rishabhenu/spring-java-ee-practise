package spring9.tutorial78AnnotationAspect;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String...strings) {
		
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("spring9/tutorial78AnnotationAspect/beans78.xml");

		Camera camera=(Camera)context.getBean("camera");
		
		camera.photo();
		
		context.close();
		
	}
}
