package com.imola.auctionenginecache;

import java.util.HashMap;
import java.util.Map;

public class Main {
	
	public static void main(String...strings) {
		Main main=new Main();
		
		Map<String,String> map=new HashMap<>();
		map.put("rishu", "Hello, This is my name");
		
		main.show(map);
	}
	
	public void show(Map<?,?> map) {
		System.out.println(map.get("rishu"));
	}
}
