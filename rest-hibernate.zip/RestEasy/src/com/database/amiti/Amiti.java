package com.database.amiti;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Amiti {
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEgroup() {
		return egroup;
	}
	public void setEgroup(String egroup) {
		this.egroup = egroup;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	private int empid;
	private String egroup;
	private String ename;
}
