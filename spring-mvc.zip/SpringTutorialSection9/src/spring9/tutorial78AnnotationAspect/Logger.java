package spring9.tutorial78AnnotationAspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class Logger {
	
	@Pointcut("execution(void spring9.tutorial78AnnotationAspect.Camera.photo())")
	public void cameraPhotoP() {}

	@Before("cameraPhotoP()")
	public void cameraPhoto() {
		System.out.println("Info : "+Camera.class+" is going to take photo");
	}
}
