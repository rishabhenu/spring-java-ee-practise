package com.email.processor;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.email.ConstantTableI.NotificationType;
import com.email.EmailBody;
import com.email.EmailSubjects;

public class EmailServices {

	private static Log log = LogFactory.getLog(EmailServices.class);

	final private String fromEmail;
	final private String password;
	final private String smtpPort;
	final private String smtpHost;

	public EmailServices(String fromEmail, String password, String smtpHost, String smtpPort) {
		this.fromEmail = fromEmail;
		this.password = password;
		this.smtpHost = smtpHost;
		this.smtpPort = smtpPort;
	}

	public void sendEmail(NotificationType nType, String toemail) {
		log.info("here setting properties");
		
		if(toemail==null||toemail.length()<=0) {log.error("email id is null");return;}
		String toEmail=toemail;
		
		String emailBody = null;
		String emailSubject = null;

		if (nType != null) {
			emailSubject = EmailSubjects.getEmailSubject(nType);
			emailBody = EmailBody.getEmailBody(nType, toEmail);
		}else {
			log.error("no notification type set,	no email sent");
			return;
		}
		Properties props = System.getProperties();
		props.put("mail.smtp.host", smtpHost);
		props.put("mail.smtp.port", smtpPort);
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		Session session = Session.getDefaultInstance(props, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(fromEmail, password);
			}
		});
		session.setDebug(true);
		try {
			Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(fromEmail));
			msg.addRecipient(RecipientType.TO, new InternetAddress(toEmail));
			msg.setSubject(emailSubject);
			msg.setText(emailBody);
			Transport.send(msg);
			log.info("email successfully sent");
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
		}
	}
}
