package SpringTutorial19copyByType;

public class HaveResult {
	
/* see difference in below objects. In SpringTutorial19copy package, I have taken 
	objects of Result Interface and named them as per its implementing classes and in xml I selected 
	Autowiring byName....But here I took objects of classes directly and selected Autowiring by type*/
	private Fail fail;
	private Pass pass;
	
	public void setFail(Fail fail) {
		this.fail = fail;
	}
	
	public void setPass(Pass pass) {
		this.pass = pass;
	}
	
	@Override
	public String toString() {
		return "HaveResult [fail=" + fail + ", pass=" + pass + "]";
	}
	
}
