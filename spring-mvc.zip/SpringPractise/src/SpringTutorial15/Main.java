package SpringTutorial15;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Main {
	
	public static void main(String args[])
	{
		ApplicationContext context=new FileSystemXmlApplicationContext("src/SpringTutorial15/beans.xml");
		
		Jungle largest=(Jungle)context.getBean("jungle");
		System.out.println("Largest animal is "+largest.getLargest());
		largest=null;
		
		Jungle jungle=(Jungle)context.getBean("jungle");
		System.out.println(jungle);
		jungle=null;
		
		((FileSystemXmlApplicationContext)context).close();
	}

}
