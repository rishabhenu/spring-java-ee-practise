package SpringTutorial21;

public class Class001  {

	@Override
	public String toString(){
		return "Hi! I'm Class001";
	}
}
