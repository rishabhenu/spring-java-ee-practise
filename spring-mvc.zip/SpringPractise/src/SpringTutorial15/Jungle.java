package SpringTutorial15;

import java.util.List;

public class Jungle {
	
	private Animal largest;
	private Animal smallest;
	private List<Animal> animals;
	
	public void setAnimals(List<Animal> animal)
	{
		this.animals=animal;
	}
	
	public void setLargest(Animal largest)
	{
		this.largest=largest;
	}
	
	public void setSmallest(Animal smallest)
	{
		this.smallest=smallest;
	}
	
	public Animal getLargest()
	{
		return largest;
	}
	
	public Animal getSmallest()
	{
		return smallest;
	}

	@Override
	public String toString() {
		StringBuilder sb=new StringBuilder();
		
		sb.append("Jungle contains: ");
		
		for(Animal a:animals)
		{
			sb.append("\n"+a);
		}
		
		return sb.toString();
	}
}
