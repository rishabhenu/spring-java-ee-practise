package SpringTutorial22;

import org.springframework.beans.factory.annotation.Qualifier;

@Qualifier("im")
public class B implements I	{

	@Override
	public String toString() {
		return "Hi! This is class B";
	}

	@Override
	public void getI()
	{
		System.out.println("I implemented in Class B");
	}
}
