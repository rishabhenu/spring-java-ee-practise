package SpringTutorial36;

import java.util.List;

public class StudentsDAO {
	
	public List<Students> getStudents(){
		return null;
	}

}
