package SpringTutorial19;

public class HaveResult {
	
	private Result fail;
	private Result pass;
	
	public void setFail(Result fail) {
		this.fail = fail;
	}
	
	public void setPass(Result pass) {
		this.pass = pass;
	}
	
	@Override
	public String toString() {
		return "HaveResult [fail=" + fail + ", pass=" + pass + "]";
	}
	
}
