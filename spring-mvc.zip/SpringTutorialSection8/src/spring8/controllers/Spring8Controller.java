package spring8.controllers;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

import spring8.spring8.Spring8;
import spring8.spring8.Spring8DAO;

@Controller
public class Spring8Controller {

	private Spring8DAO springdao;

	@Resource(name = "spring8DAO")
	public void setSpringdao(Spring8DAO springdao) {
		this.springdao = springdao;
	}

	// getting complete table
	@RequestMapping("/spring8table")
	public String getSpring8Table(Spring8 spring, Model model) {
		List<Spring8> springtable = springdao.getComplete();
		model.addAttribute("table", springtable);
		model.addAttribute("spring8", spring);
		return "spring8table";
	}

	// opening data insertion form
	@RequestMapping("/insertrecord")
	public String insertFormSpring8(Spring8 spring, Model model) {
		model.addAttribute("spring8",spring);
		return "insertrecord";
	}

	// inserting records
	@RequestMapping(value = "/inserted")
	public String insertedSpring8(@Valid Spring8 spring, BindingResult result, Model model) {
		System.out.println("insertedSpring8 method");
		model.addAttribute("sqlresult","Congrats,,, data inserted successfully");
		model.addAttribute("spring8",spring);
		if (result.hasErrors()) {
			return "insertrecord";
		} else {
			try{
				springdao.insertSpring8(spring);
			}catch(Exception e) {
				model.addAttribute("sqlresult","You are trying to enter duplicate values");
				}
		}
		return "inserted";
	}
}
