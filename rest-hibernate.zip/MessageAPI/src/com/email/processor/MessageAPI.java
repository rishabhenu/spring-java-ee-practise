package com.email.processor;

public class MessageAPI {
	private String username,full_name,email,password;
	public MessageAPI(String username, String full_name, String email, String password) {
		this.username = username;
		this.full_name = full_name;
		this.email = email;
		this.password = password;
	}
	@Override
	public String toString() {
		StringBuilder sb=new StringBuilder();
			sb.append("username: ").append(username).append("\n")
				.append("password: ").append(password);
		return sb.toString();
	}
	public String getEmail() {
		return this.email;
	}
	public String getFull_name() {
		return full_name;
	}
}
