package com.vskill.internship.exception;

public class Main {

//What is the output of following code:-
	public void show() throws Exception  {
		try{
			int i=10/0;
			System.out.println("value of i is undefined");
		}catch(ArithmeticException ae) {
			System.out.println("airthmetic exception");
			throw new Exception();
		}catch(NumberFormatException nfe) {
			System.out.println("number format exception");
		}catch(Exception e) {
			System.out.println("exception");
		}
	}
	
	public static void main(String args[]) throws Exception{
		Main main=new Main();
		main.show();
	}	
}
