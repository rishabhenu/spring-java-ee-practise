package SpringTutorial22;

public interface I {
	
	public void getI();

}
