package com.bySam;

public class LargestOfThree {
	
	public static void main(String...strings) {
		int a=90,b=90,c=90;
		System.out.println(new LargestOfThree().largestOfThree(a, b, c,1));
	}
	
	
	public int largestOfThree(int a,int b,int c,int rank) {
		int f=0,s=0,t=0;
		if(a>=b&&a>=c) {
			f=a;
			if(b>c) {s=b;t=c;}
			else {s=c;t=b;}
		}
		else if(b>=c&&b>=a) {
			f=b;
			if(c>a) {s=c;t=a;}
			else {s=a;t=c;}
		}
		else if(c>=a&&c>=b) {
			f=c;
			if(a>b) {s=a;t=b;}
			else {s=b;t=a;}
		}
		System.out.println(f+" "+s+" "+t);
		switch(rank) {
		case 1:
			return f;
		case 2:
			return s;
		case 3:
			return t;
		}
		return -1;
	}
}
