package SpringTutorial16;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import SpringTutorial15.*;

public class Main {
	
	public static void main(String args[])
	{
		ApplicationContext context=new FileSystemXmlApplicationContext("src/SpringTutorial16/beans.xml");
		
		Jungle largest=(Jungle)context.getBean("jungle");
		System.out.println("Largest animal is "+largest.getLargest());
		largest=null;
		
		Jungle smallest=(Jungle)context.getBean("jungle");
		System.out.println("Smallest animal is "+smallest.getSmallest());
		smallest=null;
		
		Jungle jungle=(Jungle)context.getBean("jungle");
		System.out.println(jungle);
		jungle=null;
		
		((FileSystemXmlApplicationContext)context).close();
	}

}
