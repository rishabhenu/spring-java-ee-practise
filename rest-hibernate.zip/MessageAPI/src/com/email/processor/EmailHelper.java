package com.email.processor;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class EmailHelper {

	private static Log log = LogFactory.getLog(EmailHelper.class);

	public static boolean validateEmailAddress(String sEmail) {
		if (sEmail == null || sEmail.length() == 0 || sEmail.indexOf(' ') != -1) {
			log.error("email is null");
			return false;
		}
		int atIndex = sEmail.indexOf('@');

		if (atIndex == -1) {
			log.error("symbol '@' is not present");
			return false;
		}
		String domain = sEmail.substring(atIndex + 1);

		if (domain.length() == 0) {
			log.error("domain not found");
			return false;
		}

		if (domain.indexOf('@') != -1) {
			log.error("double '@' symbol is not allowed in one email");
			return false;
		}

		int dot=domain.indexOf('.');
		if(dot==-1) {
			log.error("'.' is not present in email");
			return false;
		}
		
		domain=domain.substring(dot+1);
		
		if(domain==null||domain.length()<=0) {
			log.error(".com,.in etc. is missing");
			return false;
		}
		
		if(domain.contains(".")) {
			log.error("double dot is not allowed in domain");
			return false;
		}
		
		boolean result = true;
		try {
			InternetAddress tmpAddr = new InternetAddress(sEmail);
			tmpAddr.validate();
		} catch (AddressException ex) {
			log.error("Invalid InternetAddress: " + sEmail + ", cause = " + ex.getMessage());
			result = false;
		}
		log.info("email address "+sEmail+" is a valid email address");
		return result;
	}

}
