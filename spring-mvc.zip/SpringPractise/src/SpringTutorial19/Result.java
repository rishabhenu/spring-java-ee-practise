package SpringTutorial19;

public interface Result {
	
	public String getMessage();
	
}
