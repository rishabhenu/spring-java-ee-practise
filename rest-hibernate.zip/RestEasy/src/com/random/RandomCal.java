package com.random;

import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@XmlRootElement
public class RandomCal {

	Log log=LogFactory.getLog(RandomCal.class);
	
	public RandomCal() {
		log.info("RandomCal class instanciated");
	}
	
	private String name;
	private RandomClass randomClass;

	public RandomClass getRandomClass() {
		return randomClass;
	}

	public void setRandomClass(RandomClass randomClass) {
		this.randomClass = randomClass;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public RandomCal(String name, RandomClass randomClass) {
		this.name = name;
		this.randomClass = randomClass;
	}
	
	@Override
	public String toString() {
		return "RandomCal [name=" + name + ", randomClass=  ]";
	}
}
