package SpringTutorial45copy;

public class Amiti {

	private int empid;
	private String egroup;
	private String ename;
	
	public Amiti() {}
	public Amiti(int empid,String ename) {
		this.empid=empid;this.ename=ename;
	}
	public Amiti(int empid,String egroup,String ename) {
		this.empid=empid;this.egroup=egroup;this.ename=ename;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEgroup() {
		return egroup;
	}

	public void setEgroup(String egroup) {
		this.egroup = egroup;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	@Override
	public String toString() {
		return "Amiti"+empid + " [egroup=" + egroup + ", ename=" + ename + "]";
	}

}
