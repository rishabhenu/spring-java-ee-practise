package SpringTutorial19copyByType;

public interface Result {
	
	public String getMessage();
	
}
