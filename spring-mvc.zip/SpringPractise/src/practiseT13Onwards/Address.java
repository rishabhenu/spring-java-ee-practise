package practiseT13Onwards;

public class Address {

	private int houseno;
	private String place;

	public void setHouseno(int houseno) {
		this.houseno = houseno;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public Address() {}
	
	public Address(int houseno,String place)
	{
		this.houseno=houseno;
		this.place=place;
	}
	
	@Override
	public String toString() {
		return "Address [houseno=" + houseno + ", place=" + place + "]";
	}

}
