package $DatabaseConnectivities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class OracleJDBC {
	
	public static void main(String args[]) throws ClassNotFoundException, SQLException {
		
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
		
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","SYSTEM","password");  
		
		Statement st=con.createStatement();
		
		ResultSet rs=st.executeQuery("select * from students");
		
		while(rs.next()) {
			System.out.println(rs.getObject(1)+" "+rs.getObject(2)+" "+rs.getString(3));
		}
		
		System.out.println("working properly");
	}

}
