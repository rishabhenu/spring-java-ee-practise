package SpringTutorial29;

public interface I {
}
