package com.login;

import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class LoginDAO {

	private NamedParameterJdbcTemplate jdbcTemplate;
	
	/*setting datasource*/
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate=new NamedParameterJdbcTemplate(dataSource);
	}
	
	/*create new account*/
	public int createUser() {
		Login login=new Login();
		MapSqlParameterSource param=new MapSqlParameterSource();
		param.addValue("usersname", login.getUsername());
		param.addValue("password", login.getPassword());
		jdbcTemplate.update("insert into authorities(username,authority) values(:username,'USER')", param);
		return jdbcTemplate.update("insert into users(username,password,enabled) values(:username,:password,1);", param);
	}
}
