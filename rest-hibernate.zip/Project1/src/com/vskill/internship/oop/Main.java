package com.vskill.internship.oop;

//What is the output of following code:-
public class Main {

	public double add(int a,float b) {
		return (a+b);
	}
	
	public double add(float a,int b) {
		return (a+b);
	}
	
//	public static void main(String args[]) {
//		Main main=new Main();
//		System.out.println(main.add(12, 12));
//	}
}
