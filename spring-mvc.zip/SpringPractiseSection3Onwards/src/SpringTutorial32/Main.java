package SpringTutorial32;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String args[]) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("SpringTutorial32/beans.xml");
		
		Lion lion=(Lion)context.getBean("lion");
		
		System.out.println(lion);
		
		((ClassPathXmlApplicationContext)context).close();
	}

}
