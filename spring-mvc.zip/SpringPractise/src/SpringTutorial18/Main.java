package SpringTutorial18;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String args[])
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("/SpringTutorial18/beans.xml");
		
		Logger logger=(Logger)context.getBean("logger");
		System.out.println(logger);
		
		
		
		((ClassPathXmlApplicationContext)context).close();
	}
	
}
