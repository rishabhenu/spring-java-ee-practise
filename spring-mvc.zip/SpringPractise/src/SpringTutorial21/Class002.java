package SpringTutorial21;

public class Class002 {

	@Override
	public String toString() {
		return "Hi! I'm Class002";
	}
	

}
