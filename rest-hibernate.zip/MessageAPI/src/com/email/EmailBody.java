package com.email;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.email.ConstantTableI.NotificationType;
import com.email.processor.MessageAPIdao;

public final class EmailBody {
	
	private static Log log=LogFactory.getLog(EmailBody.class);
	
	private  static MessageAPIdao daoServices;
	public void setDaoServices(MessageAPIdao daoServices) {
		EmailBody.daoServices = daoServices;
	}

	public static String getEmailBody(NotificationType nType, String email) {
		StringBuilder sb = new StringBuilder("Hello ");
		switch (nType) {
		case LOGIN_ALERT:
			sb.append(daoServices.getOneUserByEmail(email).getFull_name()).append("\n")
					.append("Your account has been logged in at " + new Date()).append("\n");
			break;
		case ACCOUNT_CREATED:
			sb.append(daoServices.getOneUserByEmail(email).getFull_name()).append("\n")
				.append("Your account has been successfully created").append("\n")
				.append("at ").append(new Date()).append("\n")
				.append("Herer is the details of your account").append("\n")
				.append(daoServices.getOneUserByEmail(email)).append("\n")
				.append("Please remember this username and password for future logins");
			break;
		default:
			log.error("no specific notification type found "+nType);
			return null;
		}
		log.info(nType+" type mail is: "+sb.toString());
		return sb.toString();
	}
}
