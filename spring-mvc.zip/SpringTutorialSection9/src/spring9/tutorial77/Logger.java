package spring9.tutorial77;

public class Logger {

	public void cameraPhoto() {
		System.out.println("Info : "+Camera.class+" is going to take photo");
	}
}
